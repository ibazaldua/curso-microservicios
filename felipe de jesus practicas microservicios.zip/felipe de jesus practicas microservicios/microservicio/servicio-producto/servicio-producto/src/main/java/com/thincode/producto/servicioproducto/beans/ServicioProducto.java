package com.thincode.producto.servicioproducto.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.thincode.producto.servicioproducto.controller.Producto;


@RestController
public class ServicioProducto {
    
	@Value("${constants.saludo}")
	private String saludo;
	
	@Value("${constants.url.usuario}")
	private String urlUasuario;
	
	private RestTemplate restTemplate;
	
	@Autowired
	public ServicioProducto(RestTemplate restTemplate) {
		this.restTemplate =  restTemplate;
	}
	
	
	@GetMapping("/servicio-producto")
	public ResponseEntity<Producto> getProducto() {
		HttpStatus status =null;
		Producto producto = new Producto();
		
		producto.setProducto("manzana");
		producto.setSaludo(saludo);
		
		ResponseEntity<Usuario> response =	restTemplate.getForEntity(urlUasuario, Usuario.class);
		
		if(response.getStatusCode()== HttpStatus.OK){
			producto.setUsuario(response.getBody());
			status=HttpStatus.OK;
		}else {
			
			status =HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<Producto>(producto,status);
		
	}
}
