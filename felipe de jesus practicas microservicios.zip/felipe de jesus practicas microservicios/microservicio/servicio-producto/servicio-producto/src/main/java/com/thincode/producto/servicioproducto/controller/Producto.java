package com.thincode.producto.servicioproducto.controller;

import com.thincode.producto.servicioproducto.beans.Usuario;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
	
	public String producto;
	public String saludo;
	public Usuario usuario;
		
	

}
