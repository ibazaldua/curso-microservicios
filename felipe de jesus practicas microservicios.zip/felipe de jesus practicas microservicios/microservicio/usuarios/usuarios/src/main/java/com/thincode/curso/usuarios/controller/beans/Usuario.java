package com.thincode.curso.usuarios.controller.beans;

public class Usuario {
     private String usuario;
     private String correo;
     
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
}
