package com.thincode.curso.usuarios.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.curso.usuarios.controller.beans.Usuario;

@RestController
public class Usuarios {

	@Value("${constants.version}")
	private String version;
	
	@GetMapping("/version")
	public String version(){
		
		return "version " + version;
	}
	
	@GetMapping("/usuario")
	public ResponseEntity<Usuario>  getUsuario() {
		Usuario usuario=new Usuario();
		usuario.setUsuario("felipe");
		usuario.setCorreo("felipe.galvan@thincode.com");
		return new ResponseEntity<Usuario>(usuario,HttpStatus.OK);
	}
	
}
