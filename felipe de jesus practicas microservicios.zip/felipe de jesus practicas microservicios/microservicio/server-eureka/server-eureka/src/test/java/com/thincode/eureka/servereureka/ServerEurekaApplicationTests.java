package com.thincode.eureka.servereureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
