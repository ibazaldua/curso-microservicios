package com.thincode.practica.interfaces;

import java.util.ArrayList;

import com.thincode.practica.controller.Persona;

public interface InterfaceDB {
	
	public int altaPersona(Persona Per);
	public int bajaPersona(int id);
	public int modificacionPersona(Persona Per);
	public Persona consultarPersonaId(int id);
	public ArrayList<Persona> consultarAll();

}
