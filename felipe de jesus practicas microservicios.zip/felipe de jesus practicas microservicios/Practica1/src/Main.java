
import com.thincode.practica.services.Services;

public class Main {



	public static void main(String[] args) {	
		
	
		Services ser = new Services();
		
		ser.activeBd="MySql";
		ser.altaPersona( 1, "felipe", "20 febrero", 31, "462 691 44 11" );
		ser.altaPersona( 2, "maria",  "1 de mayo",  32, "462 691 44 22" );
		ser.altaPersona( 3, "pedro",  "revolucion", 33, "462 691 44 33" );
		ser.consPersonas();
		
		ser.modPersona(2, "maria", "2 de mayo", 32,"462 691 44 22");
		ser.consPersonas();
		
		ser.borrPersona(1);
		ser.consPersonas();
		
		ser.consPersona(3);
		
		
		ser.activeBd="Oracle";
		
		ser.altaPersona( 1, "angel",    "el charco",     41,"462 691 22 11");
		ser.altaPersona( 2, "josefina", "cascada",       42,"462 691 22 22");
		ser.altaPersona( 3, "leonel",   "benito juarez", 43,"462 691 22 33");
		ser.consPersonas();
		
		ser.modPersona( 2, "josefina", "lluvia", 42,"462 691 22 22");
		ser.consPersonas();
		
		ser.borrPersona(1);
		ser.consPersonas();
		
		ser.consPersona(3);
		
	}
	
	
	
}
