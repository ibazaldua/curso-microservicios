package usuario;

public class usuario {
	
	
	String usuario= new String();
	String nombre= new String();
	String correo= new String();
	String pasword= new String();
	String fechaAltaUsuario= new String();
	
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	public String getFechaAltaUsuario() {
		return fechaAltaUsuario;
	}
	public void setFechaAltaUsuario(String fechaAltaUsuario) {
		this.fechaAltaUsuario = fechaAltaUsuario;
	}

	
}
