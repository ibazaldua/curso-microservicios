package com.thincode.ejmplo2.demorest01.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Usuario {
	
	private String usuario;
	private String nombre;
	private String correo;
	private String password;
	private Integer edad;

}
