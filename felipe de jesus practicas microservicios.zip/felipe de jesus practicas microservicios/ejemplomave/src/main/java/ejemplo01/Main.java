package ejemplo01;

public class Main {
	public static void main(String[] args) {
		Usuarios u=new Usuarios();
		
		System.out.println(u);
		
		//ejemplo de como usar maven y que se generen varias cosas automaticamente en este caso isimos los geter y seter implisitamente 
		
		
	}


}
