package ejemplo01;

import java.sql.Date;

import lombok.Data;
import lombok.Getter;
import lombok.ToString;
import lombok.ToString.Exclude;

@Data //con esta instruccion se generan los geter y seters implisitamente
//@ToString(exclude = {"password","nombre"})  // para excluir datos que no necesitamos
@ToString
public class Usuarios {
	
	private String usuario;
	private String nombre;
	private Date fechaNacimiento;
	@Exclude // esta es la segunda fora de excluir la primera forma es la comentada arriba
	private String password;
	private Integer edad;

}
