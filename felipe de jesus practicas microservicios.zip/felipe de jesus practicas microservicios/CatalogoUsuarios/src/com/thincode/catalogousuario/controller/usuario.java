package com.thincode.catalogousuario.controller;

public class usuario {

	private String usuario;
	private String nombre;
	private String correo;
	private String edad;
	private String fecha;
	
    public usuario( ) {

    }
	
    public usuario(String usuario,String nombre , String correo, String edad,String fecha ) {
        this.usuario = usuario;
        this.nombre = nombre;
        this.correo = correo;
        this.edad = edad;
        this.fecha = fecha;
    }
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getEdad() {
		return edad;
	}
	public void setEdad(String edad) {
		this.edad = edad;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	
}
