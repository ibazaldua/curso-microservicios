package com.thincode.catalogousuarios.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.jdbc.Driver;
import com.thincode.catalogousuario.controller.usuario;

public class hiloalta extends Thread{
	
    usuario objUsuario = new usuario();
    
    public hiloalta(usuario usuario) {
        this.objUsuario = usuario;
    }
    
	
	@Override
	public void run() {
		
		StringBuilder builder = new StringBuilder();
		
		try {
			DriverManager.registerDriver(new Driver());
			
			String url = "jdbc:mysql://localhost:3306/usuario";
			Connection conn = DriverManager.getConnection(url,"root","");
			PreparedStatement ps = conn.prepareStatement("insert into tabusuarios values(?,?,?,?,?) ");
			ps.setString(1, objUsuario.getUsuario().toString());
			ps.setString(2, objUsuario.getNombre().toString());
			ps.setString(3, objUsuario.getCorreo().toString());
			ps.setString(4, objUsuario.getEdad().toString());
			ps.setString(5, objUsuario.getFecha().toString());
			
			for(int i=0;i<100;i++) {
				ps.setString(1, objUsuario.getUsuario().toString()+builder.append(i).toString());
				ps.execute();
				builder.delete(0, builder.length());
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		
	}
	
	

}
