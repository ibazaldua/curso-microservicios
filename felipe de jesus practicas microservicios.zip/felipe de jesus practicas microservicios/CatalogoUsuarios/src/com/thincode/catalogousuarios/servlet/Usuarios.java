package com.thincode.catalogousuarios.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.DriverConnectionFactory;


import com.mysql.jdbc.Driver;
import com.thincode.catalogousuario.controller.usuario;


public class Usuarios extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("Llamando a metodo ... GET");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
       System.out.println("Llamando a metodo ... pos");	
	   //String usuario = req.getParameter("txtUsuario");
	   
	   usuario objusuario =new usuario(req.getParameter("usuario"),req.getParameter("nombre"),req.getParameter("correo"),req.getParameter("edad"),req.getParameter("fecha"));
	   
	   StringBuilder builder = new StringBuilder();
	   
	   hiloalta alta =new hiloalta(objusuario);
	   
	   
	   
	
	try {
		DriverManager.registerDriver(new Driver());
		
		String url = "jdbc:mysql://localhost:3306/usuario";
		Connection conn = DriverManager.getConnection(url,"root","");
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM tabusuarios");
		
		
		alta.start();
		ResultSet res = ps.executeQuery();
		
		
		while(res.next()) {
			
			builder.append("Nombre[").append(res.getString("usuario")).append("]");
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		
		
	   PrintWriter out= resp.getWriter();
			
	   out.println(builder.toString());
	
	}

}
