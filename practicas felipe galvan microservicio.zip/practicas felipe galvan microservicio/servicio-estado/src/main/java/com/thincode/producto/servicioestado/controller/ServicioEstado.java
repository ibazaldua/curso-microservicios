package com.thincode.producto.servicioestado.controller;

import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;

import javax.websocket.server.PathParam;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.thincode.producto.servicioestado.controller.hystrix.Redireccion;


@RestController
public class ServicioEstado {
    
	
	ArrayList<Cliente> dbClientes= new ArrayList<Cliente>();
	
	@Autowired
    private Redireccion redireccion;
	
	public ServicioEstado() {
	}
	
	@Value("${constants.saludo}")
	private String saludo;
	
	@Value("${constants.url.usuario}")
	private String urlCredito;
	
	private RestTemplate restTemplate;
	

	
	
	@GetMapping("/consultacliente/{id}")
	public ResponseEntity<Cliente> getEstado(@PathVariable  String id) {
		dbClientes.clear();
		
		dbClientes.add(new Cliente("1111", "Jose Perez leon",null));
		dbClientes.add(new Cliente("2222", "carlos juarez sanchez",null));
		dbClientes.add(new Cliente("3333", "leonora galvan hernendez",null));
		dbClientes.add(new Cliente("4444", "fidel castro zamarripa",null));
		dbClientes.add(new Cliente("5555", "fernando montes de oca",null));
		dbClientes.add(new Cliente("6666", "everardo garcia linares",null));
		dbClientes.add(new Cliente("7777", "juana hernandez laguna",null));
		dbClientes.add(new Cliente("8888", "juan mireles macias",null));
		dbClientes.add(new Cliente("9999", "andrea garcilita perez",null));
		dbClientes.add(new Cliente("1010", "josefina martinez estrada",null));
		
		
		System.out.println("entro a servicio estado ["+id+"]");
		
		HttpStatus status;
		Cliente estadoCuenta = new Cliente();
		ArrayList<TarjetaCredito> listaTarjetas =new ArrayList<TarjetaCredito>();
		
		System.out.println("entro a servicio estado ["+id+"]");
		
		for (Cliente cliente: dbClientes){
			System.out.println("recuperando cliente ["+cliente.getNombreDeCliente()+"]");
			
			if(id.equals(cliente.getNumeroDeCliente())) {
				
				System.out.println("encontro cliente");
				estadoCuenta.setNumeroDeCliente(cliente.getNumeroDeCliente());
				estadoCuenta.setNombreDeCliente(cliente.getNombreDeCliente());
				
				listaTarjetas.addAll(redireccion.consultacredito(id));
				listaTarjetas.addAll(redireccion.consultaDebito(id));
				listaTarjetas.addAll(redireccion.consultaInversiones(id));
				
				
				estadoCuenta.setTarjetas(listaTarjetas);
				break;
			}	
		}
		status=HttpStatus.OK;
		return new ResponseEntity<Cliente>(estadoCuenta,status);
		
	}
}
