package com.thincode.producto.servicioestado.controller.hystrix;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import com.thincode.producto.servicioestado.controller.Cliente;
import com.thincode.producto.servicioestado.controller.TarjetaCredito;

@Component
public class Redireccion {
	@Autowired
	private RestTemplate restTemplate; 
	
	

	
	@HystrixCommand(fallbackMethod ="fallconsultacredito")
	public ArrayList<TarjetaCredito> consultacredito(String id) {
		
		ArrayList<TarjetaCredito> listaTarjetas =new ArrayList<TarjetaCredito>();
		
		ResponseEntity<Cliente> response = restTemplate.getForEntity("http://servicio-credito/tarjetascredito/"+id.toString(),Cliente.class);
		
		if(response.getStatusCode()== HttpStatus.OK){
			listaTarjetas.addAll(response.getBody().getTarjetas());
						
		}else {
			
			System.out.println("fallo el servicio de credito");
		}
		
		return listaTarjetas;
	}
	
	public ArrayList<TarjetaCredito> fallconsultacredito(String id,Throwable error) {
		System.out.println("Servicio de credito no disponible");
		return new ArrayList<TarjetaCredito>();
	}
	
	@HystrixCommand(fallbackMethod ="fallconsultaDebito")
	public ArrayList<TarjetaCredito> consultaDebito(String id) {
		
		
		ArrayList<TarjetaCredito> listaTarjetas =new ArrayList<TarjetaCredito>();
				
		ResponseEntity<Cliente> response = restTemplate.getForEntity("http://servicio-debito/tarjetasdebito/"+id.toString(),Cliente.class);
		
		if(response.getStatusCode()== HttpStatus.OK){
			listaTarjetas.addAll(response.getBody().getTarjetas());
						
		}else {
			
			System.out.println("fallo el servicio de debito");
		}
		
		return listaTarjetas;
	}
	
	public ArrayList<TarjetaCredito> fallconsultaDebito(String id,Throwable error) {
		System.out.println("Servicio de debito no disponible");
		return new ArrayList<TarjetaCredito>();
	}
	
	@HystrixCommand(fallbackMethod ="fallconsultaInversiones")
	public ArrayList<TarjetaCredito> consultaInversiones(String id) {
		
		ArrayList<TarjetaCredito> listaTarjetas =new ArrayList<TarjetaCredito>();
		
		ResponseEntity<Cliente> response = restTemplate.getForEntity("http://servicio-inversiones/tarjetasinversiones/"+id.toString(),Cliente.class);
		
		if(response.getStatusCode()== HttpStatus.OK){
			listaTarjetas.addAll(response.getBody().getTarjetas());
			
		}else {
			
			System.out.println("fallo el servicio de inversiones");
		}
		
		return listaTarjetas;
	}
	
	public ArrayList<TarjetaCredito> fallconsultaInversiones(String id,Throwable error) {
		System.out.println("Servicio de inversiones no disponible");
		return new ArrayList<TarjetaCredito>();
	}
	
	
}
