package com.thincode.practica.implementacion;

import java.util.ArrayList;

import com.thincode.practica.controller.Persona;
import com.thincode.practica.interfaces.InterfaceDB;

public class Oracle implements InterfaceDB {
	public static ArrayList<Persona> listaPersonasOracle = new ArrayList<Persona>(); 
	
	@Override
	public int altaPersona(Persona Per) {
		System.out.println("Entro a  Alta Oracle");
		listaPersonasOracle.add(Per);
		return 1;
	}

	@Override
	public int bajaPersona(int id) {
		System.out.println("Entro a  Baja Oracle");

		for(Persona  elemento : listaPersonasOracle) {
	    	if( elemento.getId() == id ) {		
	    		listaPersonasOracle.remove(elemento);
	    		return 1;
	    	}
	    }

		return 0;
	}

	@Override
	public int modificacionPersona(Persona Per) {
		System.out.println("Entro a  Modif Oracle");
		
		for(Persona  elemento : listaPersonasOracle) {
	    	if( elemento.getId() == Per.getId()) {
	    		listaPersonasOracle.set(listaPersonasOracle.indexOf(elemento),Per);
	    		return 1;
	    	}
	    }
		
		return 0;
	}

	@Override
	public Persona consultarPersonaId(int id) {
	   for(Persona  elemento : listaPersonasOracle) {
		   if( elemento.getId() == id) {
			   return listaPersonasOracle.get(listaPersonasOracle.indexOf(elemento));	   
		   }
	   }
	  
		return null;
	}

	@Override
	public ArrayList<Persona> consultarAll() {
		// TODO Auto-generated method stub
		return listaPersonasOracle;
	}

}
