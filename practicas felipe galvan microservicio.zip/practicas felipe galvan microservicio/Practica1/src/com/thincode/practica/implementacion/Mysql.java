package com.thincode.practica.implementacion;

import java.util.ArrayList;

import com.thincode.practica.controller.Persona;
import com.thincode.practica.interfaces.InterfaceDB;

public class Mysql implements InterfaceDB {
	
	public static ArrayList<Persona> listaPersonasSql = new ArrayList<Persona>(); 
		
	@Override
	public int altaPersona(Persona Per) {
		// TODO Auto-generated method stub
		System.out.println("Entro a  Alta Mysql");
		listaPersonasSql.add(Per);
		
		return 1;
	}

	@Override
	public int bajaPersona(int id) {
		
		System.out.println("Entro a  Baja Mysql");

		for(Persona  elemento : listaPersonasSql) {
			if( elemento.getId() == id) {
	    		listaPersonasSql.remove(elemento);
	    		return 1;
			}
	   	}	
	
		return 0;
	}

	@Override
	public int modificacionPersona(Persona Per) {

		System.out.println("Entro a  Modif Mysql");

		for(Persona  elemento : listaPersonasSql) {
	    	if( elemento.getId() == Per.getId()) {
	    		listaPersonasSql.set(listaPersonasSql.indexOf(elemento),Per);
	    		return 1;
	    	}
	    }
		
		return 0;
	}

	@Override
	public Persona consultarPersonaId(int id) {

		System.out.println("Entro a  Consulta Mysql");

		for(Persona  elemento : listaPersonasSql) {
	    	
	    	if( elemento.getId() == id) {
	    		return listaPersonasSql.get(listaPersonasSql.indexOf(elemento));	    		
	    	}
	    }
		
		return null;
	}
	
	@Override
	public ArrayList<Persona> consultarAll() {
		// TODO Auto-generated method stub
		return listaPersonasSql;
	}
	
}
