import java.util.Scanner;

import com.thincode.examen.service.Servicio;
import com.thincode.examen.util.Comparativa;

public class Main {
	
	public Main() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {	

		Servicio servicio= new Servicio();
		Comparativa com=new Comparativa();
		Scanner sn = new Scanner(System.in);
	    boolean salir = false;
	    String entrada; 
	    int opcion;
	        
	    while(!salir){
	       System.out.println("*****************************************");
	       System.out.println("*1. Cargar datos de Archivo             *");
	       System.out.println("*2. Consultar todos los datos en memoria*");
	       System.out.println("*3. Consultar dato por ID               *");
	       System.out.println("*4. Salir                               *");
	       System.out.println("*****************************************");
	       System.out.println("                                         ");
	       System.out.println("Escribe una de las opciones:");
	       entrada= sn.next();
	           
	       if (com.isNumeric(entrada)){
	           opcion=Integer.parseInt(entrada);
	       }else {
	           opcion = 6; 
	       }
	           
	       switch(opcion){
	          case 1:
	               servicio.cargaArchivo();
	          break;
	          case 2:
	           	   servicio.consultarDatos();
	          break;
	          case 3:  	
	               while (!salir) {
	                	
	                  System.out.println("*****************************************");
	                  System.out.println("Introduce el ID a consultar:");
	                  entrada= sn.next();
	                   
	                  if (com.isNumeric(entrada)){   
	                	   servicio.consultarDatosId(Integer.parseInt(entrada));
	                	   salir = true;
	                  }else {
	                	   System.err.println("Error id no es numerico.");
	                	   salir = false;
	                  }
	               }
	               salir = false;
	          break;
	          case 4:
	               salir=true;
	          break;
	          default:
	               System.err.println("Solo n�meros entre 1 y 4");
	          }
	            
	    }
		
	    System.out.println("*****************************************");
    	System.out.println("***********Fin de programa **************");
    	System.out.println("*****************************************");
	}
}
