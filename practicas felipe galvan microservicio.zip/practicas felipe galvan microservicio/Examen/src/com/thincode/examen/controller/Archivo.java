package com.thincode.examen.controller;

import com.thincode.examen.modelo.Registro;

import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Archivo {
	
	private Map<Integer,Registro> mapaRegistros = new HashMap<Integer, Registro>();
	 
	public boolean cargaArchivo() {
		Expresion expresion=new Expresion();
		Registro resgistro =new Registro();
		String line;
		boolean result=false;
		
		try {
            Scanner input = new Scanner(new File("c:/datos/datos.txt"));
            mapaRegistros.clear();
            while (input.hasNextLine()) {
            	
            	line = input.nextLine();
                resgistro = expresion.recuperaDatos(line);
                
                if (resgistro.getId()>0) {
                	mapaRegistros.put(resgistro.getId(), resgistro);
                }         	
            }
            
            input.close();
            result=true;
        } catch (Exception ex) {
            ex.printStackTrace();
            result=false;
        }
		
		return result;
	}
	
	public ArrayList<Registro> muestraLista() {
		
		ArrayList<Registro> listaRegistros =new ArrayList<Registro>(mapaRegistros.values());
		
		return listaRegistros;
	}
	
	
	public Registro muestraListaId(Integer id) {
		Registro registro =new Registro();;

		if(mapaRegistros.containsKey(id)) {
			registro=mapaRegistros.get(id);
		}else {
			registro= null;
		}
		
		return registro;
	}

}
