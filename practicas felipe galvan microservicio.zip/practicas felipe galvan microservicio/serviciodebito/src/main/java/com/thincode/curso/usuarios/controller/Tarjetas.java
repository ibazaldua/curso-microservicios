package com.thincode.curso.usuarios.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.curso.usuarios.controller.beans.Cliente;
import com.thincode.curso.usuarios.controller.beans.TarjetaDebito;

@RestController
public class Tarjetas {

	ArrayList<TarjetaDebito> bdTarjetas = new ArrayList<TarjetaDebito>();
	
	public Tarjetas() {
		
		bdTarjetas.add(new TarjetaDebito("1111", "123456891", "debito", 100));
		bdTarjetas.add(new TarjetaDebito("2222", "223456892", "debito", 200));
		bdTarjetas.add(new TarjetaDebito("3333", "323456893", "debito", 300));
		
		bdTarjetas.add(new TarjetaDebito("4444", "423456811", "debito", 100));
		bdTarjetas.add(new TarjetaDebito("4444", "423456822", "debito", 200));
		bdTarjetas.add(new TarjetaDebito("4444", "423456833", "debito", 300));
		bdTarjetas.add(new TarjetaDebito("4444", "423456844", "debito", 400));
	
		bdTarjetas.add(new TarjetaDebito("5555", "523456895", "debito", 500));
		bdTarjetas.add(new TarjetaDebito("6666", "623456896", "debito", 600));
		bdTarjetas.add(new TarjetaDebito("7777", "723456897", "debito", 700));
		bdTarjetas.add(new TarjetaDebito("8888", "823456898", "debito", 800));
		bdTarjetas.add(new TarjetaDebito("9999", "923456899", "debito", 900));
		bdTarjetas.add(new TarjetaDebito("1010", "023456890", "debito", 1000));
	}
	
	@GetMapping("/tarjetasdebito/{id}")
	public ResponseEntity<Cliente> getTarjetasCredito(@PathVariable String id) {
			
		Cliente cliente = new Cliente();
		
		ArrayList<TarjetaDebito> listaTarjetas =new ArrayList<TarjetaDebito>();
		
		
		for (TarjetaDebito tar:bdTarjetas) {
			
			if(id.equals(tar.getNumeroCliente())) {
				listaTarjetas.add(tar);
			}
			
		}
		cliente.setTarjetas(listaTarjetas);
		
		return new ResponseEntity<Cliente>(cliente,HttpStatus.OK);
	}
}
