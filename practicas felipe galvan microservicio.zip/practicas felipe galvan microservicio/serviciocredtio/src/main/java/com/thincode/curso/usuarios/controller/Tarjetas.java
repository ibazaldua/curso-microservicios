package com.thincode.curso.usuarios.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.curso.usuarios.controller.beans.Cliente;
import com.thincode.curso.usuarios.controller.beans.TarjetaCredito;


@RestController
public class Tarjetas {

	ArrayList<TarjetaCredito> bdTarjetas = new ArrayList<TarjetaCredito>();
	
	public Tarjetas() {
		
		bdTarjetas.add(new TarjetaCredito("1111", "123456891", "credito", 100));
		bdTarjetas.add(new TarjetaCredito("2222", "223456892", "credito", 200));
		bdTarjetas.add(new TarjetaCredito("3333", "323456893", "credito", 300));
		bdTarjetas.add(new TarjetaCredito("4444", "423456894", "credito", 400));
		bdTarjetas.add(new TarjetaCredito("5555", "523456895", "credito", 500));
		bdTarjetas.add(new TarjetaCredito("6666", "623456896", "credito", 600));
		bdTarjetas.add(new TarjetaCredito("7777", "723456897", "credito", 700));
		bdTarjetas.add(new TarjetaCredito("8888", "823456898", "credito", 800));
		bdTarjetas.add(new TarjetaCredito("9999", "923456899", "credito", 900));
		bdTarjetas.add(new TarjetaCredito("1010", "023456890", "credito", 1000));
	}
	
	@GetMapping("/tarjetascredito/{id}")
	public ResponseEntity<Cliente> getTarjetasCredito(@PathVariable String id) {
			
		Cliente cliente = new Cliente();
		
		ArrayList<TarjetaCredito> listaTarjetas =new ArrayList<TarjetaCredito>();
		
		
		for (TarjetaCredito tar:bdTarjetas) {
			
			if(id.equals(tar.getNumeroCliente())) {
				listaTarjetas.add(tar);
			}
			
		}
		cliente.setTarjetas(listaTarjetas);
		
		return new ResponseEntity<Cliente>(cliente,HttpStatus.OK);
	}
}
