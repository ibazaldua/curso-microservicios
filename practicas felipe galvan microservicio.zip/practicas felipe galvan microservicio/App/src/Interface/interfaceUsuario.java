package Interface;

import usuario.usuario;

public interface interfaceUsuario {
	
	public int altaUsiario(int id);
	public int modificarUriario(usuario Per);
	public int consultarUsuario (int id);
	public int borraUsuario (int id);
	

}
