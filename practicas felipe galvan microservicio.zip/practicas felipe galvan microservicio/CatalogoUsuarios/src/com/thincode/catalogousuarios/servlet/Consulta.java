package com.thincode.catalogousuarios.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.dbcp.dbcp2.DriverConnectionFactory;


import com.mysql.jdbc.Driver;
import com.thincode.catalogousuario.controller.usuario;


public class Consulta extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("Llamando a metodo consulta ... GET");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
       System.out.println("Llamando a metodo consulta ... pos");	
	   
	   StringBuilder builder = new StringBuilder();
	   	   
	try {
		DriverManager.registerDriver(new Driver());
		
		String url = "jdbc:mysql://localhost:3306/usuario";
		Connection conn = DriverManager.getConnection(url,"root","");
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM tabusuarios");
		
		System.out.println("Consultando en base de datos");
		
		ResultSet res = ps.executeQuery();
		
		while(res.next()) {
			
			builder.append("Nombre[").append(res.getString("usuario")).append("]");
		}
		
		//req.setAttribute("lista", o);
		
		req.getRequestDispatcher("/consulta.html").forward(req, resp);
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	  // PrintWriter out= resp.getWriter();
			
	   //out.println(builder.toString());
	
	}

}
