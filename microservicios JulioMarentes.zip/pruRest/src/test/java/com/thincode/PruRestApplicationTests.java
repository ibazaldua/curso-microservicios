package com.thincode;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.thincode.beans.Usuario;
import com.thincode.repository.UsuarioRepository;
import com.thincode.services.UsuarioService;

@SpringBootTest
public class PruRestApplicationTests {

	@Test
	public void contextLoads() {
		System.out.println("Test contextLoads");
	}

	@Test
	public void prueba01() {
		System.out.println("Test 01");
		
		System.out.println("Consulta all");
		UsuarioRepository rep = new UsuarioRepository();
		rep.consultaAll();
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
		
	}

	@Test
	public void prueba02() {
		System.out.println("Test 02");

		System.out.println("Consulta by nombre");
		UsuarioRepository rep = new UsuarioRepository();
		rep.consultaByName("Marent");
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba03() {
		System.out.println("Test 03");
		
		System.out.println("Alta");
		UsuarioRepository rep = new UsuarioRepository();
		rep.alta( new Usuario( 4, "julio", "Julio Marentes", "juliogmail.com", "*****", 53 ) );

		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba04() {
		System.out.println("Test 04");
		
		System.out.println("Consulta all");
		UsuarioRepository rep = new UsuarioRepository();
		rep.consultaAll();
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba05() {
		System.out.println("Test 05");
		
		System.out.println("Alta");
		UsuarioRepository rep = new UsuarioRepository();
		rep.alta( new Usuario( 4, "julio", "Julio Marentes", "julio@gmail.com", "*****", 53 ) );

		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba06() {
		System.out.println("Test 06");
		
		System.out.println("Consulta all");
		UsuarioRepository rep = new UsuarioRepository();
		rep.consultaAll();
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	
	@Test
	public void prueba07() {
		System.out.println("Test 07");
		
		System.out.println("Baja");
		UsuarioRepository rep = new UsuarioRepository();
		rep.baja( 4  );
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba08() {
		System.out.println("Test 08");
		
		System.out.println("Consulta all");
		UsuarioRepository rep = new UsuarioRepository();
		rep.consultaAll();
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	
	@Test
	public void prueba09() {
		System.out.println("Test 09");
		
		System.out.println("Alta ");
		UsuarioService ser = new UsuarioService();
		
		ser.altaUsuario( new Usuario( 4, "julio", "Julio Marentes", "juliogmail.com", "*****", 53 ) );
		ser.consultaAllUsuario();
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	
	
}
