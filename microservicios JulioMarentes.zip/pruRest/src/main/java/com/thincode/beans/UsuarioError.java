package com.thincode.beans;

import lombok.Data;

@Data
public class UsuarioError {

	private String timestamp;
	private String status;
	private String error;
	private String message;
	private String path;
	
	
}
