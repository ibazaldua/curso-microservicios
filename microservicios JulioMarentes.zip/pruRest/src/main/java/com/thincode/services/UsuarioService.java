package com.thincode.services;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.thincode.beans.Usuario;
import com.thincode.repository.IUsuarioRepository;
import com.thincode.repository.UsuarioRepository;

@Service
public class UsuarioService {
	
	IUsuarioRepository repo = null;
	
	public UsuarioService() {
		repo= new UsuarioRepository();
	}

	public ArrayList<Usuario> consultaAllUsuario() {
		System.out.println("UsuarioService consultaAllUsuario");

		return repo.consultaAll();
	}
	
	public void consultaByIdUsuario( int id ) {
		System.out.println("UsuarioService consultaById");
	}
	
	public ArrayList<Usuario> consultaByNameUsuario( String name ) {
		System.out.println("UsuarioService consultaByName");
		
		return repo.consultaByName( name); 
	}
	
	public Usuario altaUsuario( Usuario usu ) {
		System.out.println("UsuarioService altaUsuario");
		Usuario u = null;
		
		Pattern patronEmail = Pattern.compile("^([\\.A-Za-z0-9]+)@([\\.a-z0-9]+)(\\.[a-z]{2,})$");
		String correo = usu.getCorreo();
        Matcher mEmail = patronEmail.matcher( correo );
        if ( mEmail.matches() ) {
           System.out.println("Correo valido " + correo);
        	u = repo.alta( usu );
        } else {
        	System.out.println("Correo invalido " + correo);
        	String s = usu.getCorreo() + " CORREO INVALIDO (Usuario no dado de alta)";
        	usu.setCorreo(s);
        	u = usu;
        }
		return u;
	}
	
	public void bajaUsuario( int id ) {
		System.out.println("UsuarioService bajaUsuario");
		repo.baja(id);
	}
	
	public Usuario cambioUsuario( Usuario usu ) {
		System.out.println("UsuarioService cambioUsuario");
		return repo.cambio(usu);
	}
	
	
}
