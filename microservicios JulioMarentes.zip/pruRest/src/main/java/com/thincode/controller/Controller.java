package com.thincode.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.beans.Usuario;
import com.thincode.services.UsuarioService;

@RestController
public class Controller {
	UsuarioService us = null;
	
	@Autowired
	public Controller(  UsuarioService us  ) {
		this.us = us;
	}
	
	@GetMapping("/version")
	public String version() {
		return "<h1>REST ver. 1.1</h1>";
	}

	@GetMapping("/usuario")
	public ArrayList<Usuario> consultaAllUsu() {
		System.out.println("Controller Consulta usuario");
		return us.consultaAllUsuario();
	}
	
	@GetMapping(value = "/usuario/{userName}")
    public ArrayList<Usuario> consultaByUsu( @PathVariable("userName") String userName ) 
    {
		System.out.println("Controller Consulta usuario by name");
        return us.consultaByNameUsuario( userName );
    }
	
	@PostMapping("/usuario")
	public Usuario altaUsu( @RequestBody Usuario usuario  ) {
		System.out.println("Controller Alta usuario");
		return us.altaUsuario( usuario );
	}
	
	@PutMapping("/usuario")
	public Usuario modificaUsu( @RequestBody Usuario usuario ) {
		System.out.println("Controller Modifica usuario");
		return us.cambioUsuario( usuario );
	}
	
	@DeleteMapping("/usuario/{id}")
	public void eliminaUsu(  @PathVariable("id") int id ) {
		System.out.println("Controller Elimina usuario");
		us.bajaUsuario( id );
	}
	
}
