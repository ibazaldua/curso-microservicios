package com.thincode.pruWebDb.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import com.mysql.jdbc.Driver;


public class UsuAsinc extends Thread {

	private Integer inicio;
	private Integer cuantos;
	private String nombre;

	public UsuAsinc( Integer inicio, Integer cuantos, String nombre) {
		super();
		this.inicio = inicio;
		this.cuantos = cuantos;
		this.nombre = nombre;
	}
	
	public UsuAsinc() {
	}

	@Override
	public void run() {
		
		String url="jdbc:mysql://localhost:3306/micro";
		String dbnombre;
		try {

			DriverManager.registerDriver(new Driver());
			Connection conn = DriverManager.getConnection(url, "root", "root");
			
			for ( int i=inicio ; i < cuantos+inicio ; i++) {
				dbnombre = nombre + i;
				System.out.println("UsuAsinc - run " + dbnombre );

				PreparedStatement ps = conn.prepareStatement("insert into usuario values ( ?, ? )" );
				ps.setInt(1, i);
				ps.setString(2, dbnombre );
				ps.execute();
				
				Thread.sleep(1500);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

	
}


