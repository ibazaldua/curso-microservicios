package com.thincode;

// import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruRegExpApplication {

	public static void main(String[] args) {
		// SpringApplication.run(PruRegExpApplication.class, args);
		
		Menu m = new Menu();
		
		m.muestraMenu();
		m.prueba();
		
		System.out.println("hola");
		
	}

}
