package com.thincode;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.context.annotation.ScannedGenericBeanDefinition;

public class Menu {
	
	String strOpcion;
	int    iOpc;
	
	public int muestraMenu() {
		
		Scanner sc = new Scanner( System.in ); 
				
		System.out.println("PROCESAMIENTO DE ARCHIVO DE PERSONAS");
		System.out.println("====================================");
		System.out.println("1.- Carga");
		System.out.println("2.- Consulta Completa");
		System.out.println("3.- Consulta Especifica");
		System.out.println("9.- Salir");
		System.out.println("Teclee Opcion");
		
		return 0;
	}
	
	public void prueba() {
		
		String s = "		1 Julio Cesar Marentes Limon       53 03-02-1966	 julio_Marentes@gmail.thincode.com otrfojksdfk";
		// String patron = "^([\\.A-Za-z0-9]+)@([\\.a-z0-9]+)(\\.[a-z]{2,})$";
		String patron = "^[ 	]*([0-9]+)[ 	]+([^0-9]+)[ 	]+([0-9]+)[ 	]+([0-9]{2,4}[/-][0-9]{2}[/-][0-9]{2,4})[ 	]+([A-Za-z\\._]+@[A-Za-z_\\.]+\\.[a-z]{2,3})";

		System.out.println(s);
		Pattern patPatron = Pattern.compile(patron);
        Matcher matPatron = patPatron.matcher( s );

        if ( matPatron.find() ) {
        	System.out.println("encontrados = " + matPatron.groupCount() );

        	for ( int i=0 ; i <= matPatron.groupCount() ; i++ )		// if ( mEmail.matches() ) {}
        		System.out.println( i + " [" + matPatron.group(i).trim() + "]" );
        } else
        	System.out.println("Cadena con formato incorecto");
		
	}
	

}
