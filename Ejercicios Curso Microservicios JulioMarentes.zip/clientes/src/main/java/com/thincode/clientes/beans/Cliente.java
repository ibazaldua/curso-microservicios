package com.thincode.clientes.beans;

import java.util.ArrayList;

public class Cliente {

	private int cliente;
	private String nombre;
	private ArrayList<Cuenta> cuenta;
	
	public Cliente(int cliente, String nombre, ArrayList<Cuenta> cuenta) {
		super();
		this.cliente = cliente;
		this.nombre = nombre;
		this.cuenta = cuenta;
	}

	public Cliente() {
		super();
	}

	public int getCliente() {
		return cliente;
	}

	public void setCliente(int cliente) {
		this.cliente = cliente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ArrayList<Cuenta> getCuenta() {
		return cuenta;
	}

	public void setCuenta(ArrayList<Cuenta> cuenta) {
		this.cuenta = cuenta;
	}

	@Override
	public String toString() {
		return "Cliente [cliente=" + cliente + ", nombre=" + nombre + ", cuenta=" + cuenta + "]";
	}

	
}
