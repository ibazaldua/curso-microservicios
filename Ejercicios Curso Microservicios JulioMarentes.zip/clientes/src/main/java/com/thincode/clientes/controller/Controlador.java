package com.thincode.clientes.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import com.thincode.clientes.beans.Cliente;
import com.thincode.clientes.beans.Cuenta;

@RestController
public class Controlador {
	
	@Value("${constants.version}")
	private String version;
	
//	private String urlCuenta = "http://cuentas/cuenta";
//	private String urlCuentas = "http://cuentas/cuentas";

	private String urlCuenta[] = { "http://cuentaInversiones/cuenta" };
	private String urlCuentas[] = { "http://cuentaInversiones/cuentas",
									"http://cuentaTarjCredito/cuentas"
	};
	
	private RestTemplate restTemplate;
	
	@Autowired
	public Controlador( RestTemplate restTemplate ) {
		this.restTemplate = restTemplate;
	}
	
	@GetMapping("/cliente")
	@HystrixCommand( fallbackMethod = "getCliente_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "100")
	})
	public ResponseEntity<Cliente> getCliente() {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		
		cte.setCliente(1);
		cte.setNombre("Julio Marentes");
		cte.setCuenta(null);
		
		ResponseEntity<Cuenta> response = restTemplate.getForEntity( urlCuenta[0],  Cuenta.class );
		if ( response.getStatusCode() == HttpStatus.OK ) {
			lista.add( response.getBody() );
			cte.setCuenta(lista);
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	public ResponseEntity<Cliente> getCliente_fallback() {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		
		cte.setCliente(1);
		cte.setNombre("Julio Marentes");
		lista.add( new Cuenta( 0, "Informacion de Cuentas no disponible", 0  ) );
		cte.setCuenta(lista);
		
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/estadoCuenta")
	@HystrixCommand( fallbackMethod = "getCliente_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "100")
	})
	public ResponseEntity<Cliente> getEstadoCuenta() {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();

		ArrayList<Cuenta> lista = null;
		
		cte.setCliente(1);
		cte.setNombre("Julio Marentes");
		cte.setCuenta(null);
		
		ResponseEntity<Object> response = restTemplate.getForEntity( urlCuentas[0],  Object.class );
		if ( response.getStatusCode() == HttpStatus.OK ) {
			lista = ( ArrayList<Cuenta> ) response.getBody();
			status = HttpStatus.OK;
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
	
		cte.setCuenta(lista);
		
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<Cuenta> getCuentas( String urlCuentas, HttpStatus status  ){
		
		ArrayList<Cuenta> lista = null;
		
		System.out.println("urlCuentas  [" + urlCuentas + "]");
		
		ResponseEntity<Object> response = restTemplate.getForEntity( urlCuentas,  Object.class );
		if ( response.getStatusCode() == HttpStatus.OK ) {
			lista = ( ArrayList<Cuenta> ) response.getBody();
			status = HttpStatus.OK;
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		System.out.println("status  [" + status + "]" + "Registros ["+ lista.size()  +"]");
		
		for( Cuenta c : lista )
			System.out.println(c);
		
		return lista;
	}

	@GetMapping("/version")
	public String version() {
		return "<h1>Version " + version + "</h1>";
	}
	
}
