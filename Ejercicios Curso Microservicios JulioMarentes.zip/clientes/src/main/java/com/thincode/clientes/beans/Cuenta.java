package com.thincode.clientes.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Cuenta {
	
	private int    numCuenta;
	private String tipoCuenta;
	private int    saldo;
	
		
}
