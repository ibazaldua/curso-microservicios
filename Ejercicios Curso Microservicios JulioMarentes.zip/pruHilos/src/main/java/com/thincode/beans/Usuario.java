package com.thincode.beans;

public class Usuario {

	private String usuario;
	private String nombre;
	private String correo;
	private String password;
	private Integer edad;
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getEdad() {
		return edad;
	}
	public void setEdad(Integer edad) {
		this.edad = edad;
	}
	public Usuario(String usuario, String nombre, String correo, String password, Integer edad) {
		super();
		this.usuario = usuario;
		this.nombre = nombre;
		this.correo = correo;
		this.password = password;
		this.edad = edad;
	}
	public Usuario() {
		super();
	}
	
	@Override
	public String toString() {
		return "Usuario [usuario=" + usuario + ", nombre=" + nombre + ", correo=" + correo + ", password=" + password
				+ ", edad=" + edad + "]";
	}
	
	
	
}
