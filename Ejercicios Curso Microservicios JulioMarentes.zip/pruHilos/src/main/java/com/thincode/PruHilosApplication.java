package com.thincode;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.thincode.beans.Hilo;
import com.thincode.beans.Usuario;

@SpringBootApplication
public class PruHilosApplication {

	public static void main(String[] args) {
		// SpringApplication.run(PruHilosApplication.class, args);
		System.out.println("hola");
		
		Usuario u = new Usuario( "julio", "Julio Marentes", "julio@gmail.com", "xxxxx", 53 );
		
	    System.out.println(u);
	    
	    Hilo h1 = new Hilo();
	    h1.start();
	    
	    System.out.println("Despues de hilo");
		
	}

}
