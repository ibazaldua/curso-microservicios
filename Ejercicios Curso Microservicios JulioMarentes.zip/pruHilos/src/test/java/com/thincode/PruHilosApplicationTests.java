package com.thincode;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruHilosApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("Test 01");
	}

}
