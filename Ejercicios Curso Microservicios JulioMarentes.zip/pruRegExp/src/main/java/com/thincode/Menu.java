package com.thincode;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.context.annotation.ScannedGenericBeanDefinition;

import com.thincode.util.Util;

public class Menu {
	
	String strOpcion;
	int    iOpc;
	
	public int muestraMenu() {
		
		String linea;
		String strOpc=null;
		int opc=0;
		Scanner sc = new Scanner( System.in ); 
				
		System.out.println("\nPROCESAMIENTO DE ARCHIVO DE PERSONAS");
		System.out.println("====================================");
		System.out.println("1.- Carga");
		System.out.println("2.- Consulta Completa");
		System.out.println("3.- Consulta Especifica");
		System.out.println("9.- Salir");
		System.out.print("Teclee Opcion : ");
		linea=sc.next().trim();

		strOpc= Util.validaExp( linea, "^([1239])$");
		if ( strOpc != null ) {
			opc = Integer.parseInt(linea);
		} else { 
			System.out.println("Opcion erronea");
		}
		
		return opc;
	}
}
