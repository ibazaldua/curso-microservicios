package com.thincode.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {

	public static String validaExp( String s, String exp  ) {
		String resp = null; 
		Pattern patPatron = Pattern.compile(exp);
        Matcher matPatron = patPatron.matcher( s );

        if ( matPatron.find() ) { 
        	resp=matPatron.group(1).trim();
        }		
		return resp;
	}
	
}
