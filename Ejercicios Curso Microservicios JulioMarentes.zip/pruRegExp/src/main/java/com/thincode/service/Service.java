package com.thincode.service;

import java.util.Map;

import com.thincode.Archivo;
import com.thincode.Menu;
import com.thincode.beans.Persona;

public class Service {
	
	Map<Integer, Persona> lista = null;
	Archivo arch = null;
	Menu menu = null;
	
	public Service() {
		arch=new Archivo();
		menu = new Menu();
	}
	
	public void menuPrincipal() {
		int opc=0;
		
		while ( opc != 9 ) {
			opc=menu.muestraMenu();
			switch( opc ) {
			case 1 :
				lista=arch.cargaArchivo();
				break;
			case 2 :
				if ( lista != null) 
					arch.muestraPersonas( lista );
				else
					System.out.println("Lista vacia");
				break;
			case 3 :
				if ( lista != null) 
					arch.muestraPersonaById( lista );
				else
					System.out.println("Lista vacia");
				break;
			default :
				break;
			}
		}
	}
	
}
