package com.thincode;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thincode.beans.Persona;
import com.thincode.util.Util;

public class Archivo {
	
	Scanner sc = null;
	
	public Archivo() {
		sc = new Scanner( System.in );
	}
	
	
	
	public Map<Integer, Persona> cargaArchivo() {
		
		String archivo = "src/main/resources/usuarios.txt";
		String linea;
		Persona p;
		int ind=0;
		
		Map<Integer, Persona> lista = new HashMap<Integer, Persona>();
		
		System.out.println("Carga de archivo");
		
		try {
			
			FileReader f = new FileReader(archivo);
			BufferedReader b = new BufferedReader(f);
			while ((linea = b.readLine()) != null) {
				p = analizaLinea(linea);
				if ( p != null )
					ind=p.getId();
					lista.put( ind, p );
			}
			  b.close();
		} catch (Exception e) { e.printStackTrace(); } 
		
		return lista;
	}
	
	public Persona analizaLinea( String s ) {
		
		Persona per = null;
		
		String patron = "^[ 	]*([0-9]+)[ 	]+([^0-9]+)[ 	]+([0-9]+)[ 	]+([0-9]{2,4}[/-][0-9]{2}[/-][0-9]{2,4})[ 	]+([A-Za-z\\._]+@[A-Za-z_\\.]+\\.[a-z]{2,3})";

		System.out.println( "Analizando: [" + s + "]");
		Pattern patPatron = Pattern.compile(patron);
        Matcher matPatron = patPatron.matcher( s );

        if ( matPatron.find() ) {
        	per = new Persona();
        	per.setId(Integer.valueOf( matPatron.group(1).trim() ));
        	per.setNombre( matPatron.group(2).trim() );
        	per.setEdad(Integer.valueOf( matPatron.group(3).trim() ));
        	per.setFechanac(matPatron.group(4).trim());
        	per.setCorreo(matPatron.group(5).trim());

        } else {
        	System.out.println("Cadena con formato incorecto");
        }
		
		return per;
	}
	
	public void muestraPersonas( Map<Integer, Persona> lista ) {
		
		Iterator<Integer> it = lista.keySet().iterator();
		Integer key;
		while(it.hasNext()){
		  key = it.next();
		  Persona p =  lista.get(key);
		  System.out.println( "Clave: " + key + " -> Valor: " + p );
		}
	}

	public void muestraPersonaById(  Map<Integer, Persona> lista ) {
		String linea;
		Integer id=null;
		String strOpc=null;

		
		while( true ) {
			System.out.print("\nTeclee el id de la persona que desea consultar [Q para salir] : ");
			linea=sc.next().trim();
	
			strOpc= Util.validaExp( linea, "^(Q|q)$");
			if ( strOpc != null ) {
				System.out.println("Salir");
				break;
			} else {
				strOpc= Util.validaExp( linea, "^([0-9]+)$");
				if ( strOpc != null ) {
					// System.out.println("Opcion : [" + strOpc + "]" );
					id = Integer.parseInt(strOpc);
					if ( lista.containsKey(id) )
						System.out.println( lista.get(id) );
					else
						System.out.println("Id no existente");
				} else {
					System.out.println("Error");
				}
			}
		}
	}
	
}
