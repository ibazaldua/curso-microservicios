package com.thincode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

// import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.thincode.beans.Persona;
import com.thincode.service.Service;

@SpringBootApplication
public class PruRegExpApplication {

	public static void main(String[] args) {
		// SpringApplication.run(PruRegExpApplication.class, args);
		
		Service ser = new Service();
		ser.menuPrincipal();
		
	}
}
