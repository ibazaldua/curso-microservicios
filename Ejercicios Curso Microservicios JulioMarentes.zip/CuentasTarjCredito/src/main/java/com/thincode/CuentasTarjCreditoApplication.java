package com.thincode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuentasTarjCreditoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuentasTarjCreditoApplication.class, args);
	}

}
