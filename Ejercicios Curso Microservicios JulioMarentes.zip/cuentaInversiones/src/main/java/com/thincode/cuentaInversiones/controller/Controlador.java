package com.thincode.cuentaInversiones.controller;

import java.util.ArrayList;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.cuentaInversiones.beans.Cuenta;

@RestController
public class Controlador {

	@GetMapping("/saludo")
	public String saludo() {
		return "Hola desde Cuentas";
	}
	
	@GetMapping("/cuenta")
	public ResponseEntity<Cuenta> getCuenta() {
		Cuenta cta = new Cuenta( 12345678, "Cuenta de Inversion / Cetes", 1000 );
		return new ResponseEntity<Cuenta>( cta, HttpStatus.OK );
	}
	
	@GetMapping("/cuentas")
	public ResponseEntity< ArrayList<Cuenta> > getCuentas() {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		lista.add(new Cuenta( 12345678, "Cuenta de Inversion / Plazo Fijo", 1000 ));
		lista.add(new Cuenta( 24680246, "Cuenta de Inversion / Cetes", 2000 ));
		lista.add(new Cuenta( 36925814, "Cuenta de Inversion / Taza Variable", 3000 ));
		ResponseEntity<ArrayList<Cuenta>> respuesta = new ResponseEntity<ArrayList<Cuenta>>( lista, HttpStatus.OK ); 
		return respuesta;
	}
	
}
