package com.thincode.estadoCuentaZuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstadoCuentaZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
