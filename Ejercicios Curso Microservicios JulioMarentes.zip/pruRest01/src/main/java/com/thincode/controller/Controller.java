package com.thincode.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	@GetMapping("/saludo")
	public String saludo() {
		System.out.println("hola");
		return "<h1>hola</h1>";
	}
	
}
