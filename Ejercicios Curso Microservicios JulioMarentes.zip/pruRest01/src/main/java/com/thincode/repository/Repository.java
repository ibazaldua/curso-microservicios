package com.thincode.repository;

public class Repository {

}
