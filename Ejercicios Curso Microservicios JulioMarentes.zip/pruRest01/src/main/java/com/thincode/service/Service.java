package com.thincode.service;

public class Service {

}
