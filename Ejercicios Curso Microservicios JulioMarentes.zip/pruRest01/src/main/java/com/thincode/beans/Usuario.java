package com.thincode.beans;

import lombok.Data;

@Data
public class Usuario {

	private Integer id;
	private String usuario;
	private String nombre;
	private String correo;
	private String password;
	private Integer edad;
		
}
