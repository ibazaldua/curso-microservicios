package com.thincode;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PruRest01ApplicationTests {

	@Test
	public void contextLoads() {
		System.out.println("Test 00");
	}

	@Test
	public void prueba01() {
		System.out.println("Test 01");
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
		
	}

	@Test
	public void prueba02() {
		System.out.println("Test 02");
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba03() {
		System.out.println("Test 03");
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba04() {
		System.out.println("Test 04");
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}

	@Test
	public void prueba05() {
		System.out.println("Test 05");
		try {
			Thread.sleep(2000);
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	
}
