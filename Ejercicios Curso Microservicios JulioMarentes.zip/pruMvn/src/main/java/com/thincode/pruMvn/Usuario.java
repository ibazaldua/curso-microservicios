package com.thincode.pruMvn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = { "password", "fechaNac" } )
public class Usuario {
	
	private String usuario;
	private String nombre;
	private String fechaNac;
	private String password;
	private int edad;
	
}
