package com.thincode.pruMvn;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hola");
		
		Usuario user = new Usuario( "julio", "Julio Cesar", "1966/02/03", "*****", 53  );
		
		System.out.println(user);
	}

}
