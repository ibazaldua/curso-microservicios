package com.thincode.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.Driver;

public class Factory {

	Connection conn = null;
	String url = "jdbc:mysql://localhost:3306/micro";
	
	public Factory() {
		System.out.println("Constructor Factory " + conn);
		if ( conn == null ) {
			try {
				DriverManager.registerDriver( new Driver());
				conn = DriverManager.getConnection(url, "root", "root");
			} catch (Exception e) { e.printStackTrace(); }
		}
	}
	
	public Connection getConexion() {
		
		return conn;
	}
}
