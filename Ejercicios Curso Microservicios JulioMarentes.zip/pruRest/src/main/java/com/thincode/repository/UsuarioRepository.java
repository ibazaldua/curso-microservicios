package com.thincode.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.thincode.beans.Usuario;
import com.thincode.util.Factory;

public class UsuarioRepository implements IUsuarioRepository{

	Connection conn = null;
	
	public UsuarioRepository() {
		Factory fac = new Factory();
		conn = fac.getConexion();
		System.out.println("Constructor UsuarioRepoitory " + conn.toString());
	}
	
	@Override
	public Usuario alta( Usuario usu ) {
		System.out.println("UsuarioRepository alta");

		if ( conn != null) {
			System.out.println("Conexion " + conn.toString());
			try {
				// PreparedStatement ps = conn.prepareStatement("insert into usuarios values (?,?,?,?, AES_ENCRYPT('thincode', ?) ,?)");
				PreparedStatement ps = conn.prepareStatement("insert into usuarios values (?,?,?,?,?,?)");
				ps.setInt(    1, usu.getId() );
				ps.setString( 2, usu.getUsuario() );
				ps.setString( 3, usu.getNombre());
				ps.setString( 4, usu.getCorreo());
				ps.setString( 5, usu.getPassword());
				ps.setInt(    6, usu.getEdad());
				
				ps.execute();
		
				} catch (Exception e) { e.printStackTrace(); }
		} else {
			System.out.println("Aplicacion sin Conexion");
		}

		return usu;
	}

	@Override
	public void baja( int id ) {
		System.out.println("UsuarioRepository baja");
		
		if ( conn != null) {
			System.out.println("Conexion " + conn.toString());
			try {
				PreparedStatement ps = conn.prepareStatement("delete from usuarios where id = ?");
				ps.setInt( 1, id  );
				
				ps.execute();
		
				} catch (Exception e) { 
					e.printStackTrace();
				}
		} else {
			System.out.println("Aplicacion sin Conexion");
		}

	}

	@Override
	public Usuario cambio( Usuario usu ) {
		System.out.println("UsuarioRepository cambio");
		
		if ( conn != null) {
			System.out.println("Conexion " + conn.toString());
			try {
				System.out.println("baja");
				PreparedStatement ps = conn.prepareStatement("delete from usuarios where id = ?");
				ps.setInt(    1, usu.getId() );
				ps.execute();
				System.out.println("alta");
				ps = conn.prepareStatement("insert into usuarios values (?,?,?,?,?,?)");
				ps.setInt(    1, usu.getId() );
				ps.setString( 2, usu.getUsuario() );
				ps.setString( 3, usu.getNombre());
				ps.setString( 4, usu.getCorreo());
				ps.setString( 5, usu.getPassword());
				ps.setInt(    6, usu.getEdad());
				
				ps.execute();
		
				} catch (Exception e) { 
					e.printStackTrace();
				}
		} else {
			System.out.println("Aplicacion sin Conexion");
		}
	
		return usu;
	}

	@Override
	public ArrayList<Usuario> consultaAll() {
		System.out.println("UsuarioRepository consultaAll");
		
		ArrayList<Usuario> lista = new ArrayList<Usuario>();
		
		if ( conn != null) {
			System.out.println("Conexion " + conn.toString());
			try {
				PreparedStatement ps = conn.prepareStatement("select * from usuarios");
				ResultSet rs = ps.executeQuery();
				while( rs.next() ) {
					Usuario u = new Usuario();
					
					u.setId( rs.getInt("id") );
					u.setUsuario( rs.getString("usuario") );
					u.setNombre( rs.getString("nombre"));
					u.setCorreo(rs.getString("correo"));
					u.setPassword(rs.getString("password"));
					u.setEdad( rs.getInt("edad"));
					
					System.out.println( u );
					lista.add(u);
				}
			} catch (Exception e) { e.printStackTrace(); }
		} else {
			System.out.println("Aplicacion sin Conexion");
		}

	return lista;
	}

	@Override
	public Usuario consultaById( int id ) {
		System.out.println("UsuarioRepository consultaBy");
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public ArrayList<Usuario> consultaByName( String nombre ) {
		System.out.println("UsuarioRepository consultaByName");

		ArrayList<Usuario> lista = new ArrayList<Usuario>();
		
		if ( conn != null) {
			System.out.println("Conexion " + conn.toString());
			try {
				PreparedStatement ps = conn.prepareStatement("select * from usuarios where nombre like ? escape '!'");
				ps.setString(1, "%" + nombre + "%");
				ResultSet rs = ps.executeQuery();
				while( rs.next() ) {
					Usuario u = new Usuario();
					
					u.setId( rs.getInt("id") );
					u.setUsuario( rs.getString("usuario") );
					u.setNombre( rs.getString("nombre"));
					u.setCorreo(rs.getString("correo"));
					u.setPassword(rs.getString("password"));
					u.setEdad( rs.getInt("edad"));
					
					System.out.println( u );
					lista.add(u);
				}
			} catch (Exception e) { e.printStackTrace(); }
		} else {
			System.out.println("Aplicacion sin Conexion");
		}

	return lista;
	}


}
