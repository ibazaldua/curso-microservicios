package com.thincode.repository;

import java.util.ArrayList;

import com.thincode.beans.Usuario;

public interface IUsuarioRepository {
	
	public Usuario alta( Usuario u );
	public void  baja( int id );
	public Usuario cambio( Usuario u );	
	public ArrayList<Usuario> consultaAll();
	public Usuario consultaById( int id );
	public ArrayList<Usuario> consultaByName( String nombre );

}
