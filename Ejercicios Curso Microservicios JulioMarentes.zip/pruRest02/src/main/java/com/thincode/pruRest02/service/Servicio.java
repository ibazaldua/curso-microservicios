package com.thincode.pruRest02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.thincode.pruRest02.beans.Persona;
import com.thincode.pruRest02.repository.Repositorio;

// @Service
public class Servicio {

	public String nombre;
	// @Autowired
	public Repositorio repo;

	@Autowired
	public Servicio ( Repositorio repo) {
		this.repo = repo;
	}
	
	public Persona consulta() {
	
		return new Persona( 1, nombre + repo.alta(), "julio@gmail.com", "3/02/1966", 8 );
	}

}
