package com.thincode.pruRest02.service;

import com.thincode.pruRest02.beans.Persona;

public class Service {

	public Persona consulta() {
		
		return new Persona( 1, "Julio", "julio@gmail.com", "3/02/1966", 53);
	}
	
}
