package com.thincode.pruRest02.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.thincode.pruRest02.beans.Persona;
import com.thincode.pruRest02.repository.Repositorio;
import com.thincode.pruRest02.service.Servicio;

@Configuration
public class Configuracion {
	
	@Bean
	public Servicio generaServicio1( Repositorio repo ) {
		Servicio ser = new Servicio( repo );
		ser.nombre = "Julio Cesar";
		return ser; 
	}

	@Bean
	public Servicio generaServicio2( Repositorio repo ) {
		Servicio ser = new Servicio( repo );
		ser.nombre = "Anna Romina";
		return ser; 
	}

	@Bean
	@Primary
	public Servicio generaServicio3( Repositorio repo ) {
		Servicio ser = new Servicio( repo );
		ser.nombre = "Bruno Sebastian";
		return ser; 
	}

	
	
	
	@Bean
	public Persona generaPersona() {
		return new Persona(); 
	}

	
}
