package com.thincode.pruRest02.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Usuario {

	private Integer clave;
	private String usuario;
	private String nombre;
	private String correo;
	private String passsword;
	private String fecIngreso;
	
}
