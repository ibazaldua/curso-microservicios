package com.thincode.pruRest02.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.pruRest02.beans.Persona;
import com.thincode.pruRest02.service.Service;
import com.thincode.pruRest02.service.Servicio;

@RestController
public class Controller {

	// @Autowired
	// @Qualifier("generaServicio1")
	private Servicio ser1;
	
	// @Autowired
	// @Qualifier("generaServicio2")
	private Servicio ser2;
	
	@Autowired
	public Controller( Servicio ser1, @Qualifier("generaServicio2") Servicio ser2 ) {
		this.ser1 = ser1;
		this.ser2 = ser2;
	}
	
	@GetMapping("/saludo")
	public String saludo() {
		return "hola";
	}
	
	@GetMapping("/persona")
	public Persona persona() {
		 
		
		return ser2.consulta();
	}
}
