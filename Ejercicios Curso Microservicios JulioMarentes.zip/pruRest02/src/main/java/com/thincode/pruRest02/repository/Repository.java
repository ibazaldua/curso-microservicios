package com.thincode.pruRest02.repository;

public class Repository {

}
