package com.thincode.pruRest02.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Persona {

	private Integer id;
	private String  nombre;
	private String  correo;
	private String  fecNac;
	private Integer edad;
	
}
