package com.thincode.pruRest02.controller;

public class Controlador {

}
