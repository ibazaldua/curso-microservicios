package com.thincode.pruRest02.repository;

import org.springframework.stereotype.Repository;

@Repository
public class Repositorio {

	public int alta() {
		return 5;
	}
	
}
