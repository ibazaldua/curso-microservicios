package com.thincode.pruRest02;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruRest02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
