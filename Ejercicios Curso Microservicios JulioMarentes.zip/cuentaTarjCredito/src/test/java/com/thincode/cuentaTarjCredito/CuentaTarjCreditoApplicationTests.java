package com.thincode.cuentaTarjCredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuentaTarjCreditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
