package com.thincode.cuentaTarjCredito.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.thincode.cuentaTarjCredito.beans.Cuenta;

@Service
public class Servicio {

	public Cuenta getCuenta() {
		Cuenta cta = new Cuenta( 12345678, "Tarjeta de Credito / Oro", 1000 );
		return cta;
	}

	public ArrayList<Cuenta> getCuentas() {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		lista.add( new Cuenta( 12345678, "Tarjeta de Credito / Oro", 1000 ));
		lista.add( new Cuenta( 24680246, "Tarjeta de Credito / Plata", 2000 ));
		lista.add( new Cuenta( 36925814, "Tarjeta de Credito / Platino", 3000 ));
		
		return lista;
	}

	
	
}
