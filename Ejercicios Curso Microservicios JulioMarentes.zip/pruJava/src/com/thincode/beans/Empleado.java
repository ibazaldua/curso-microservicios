package com.thincode.beans;

public class Empleado extends Usuario {

	public void prueba00() {

		Empleado e = new Empleado();
		
		//  e.		public protect default
		
	}
}
