package com.thincode.beans;

public class AdmBeans {
	
	public void prueba() {

		Usuario a = new Usuario();
		
		// a.			public protect default
	
	}

}
