package com.thincode.beans;

public class Usuario {
	
	private String priv_usuario;
	public String pub_nombre;
	String def_correo;
	protected String protec_password;
	private Integer edad;

	public void prueba() {
		
		Usuario u = new Usuario();
		
		// u.		public protect default private
		
	}

}
