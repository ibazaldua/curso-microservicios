package com.thincode;

import com.thincode.beans.Empleado;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hola");
		
		Empleado emp = new Empleado();
		
	
		
		
		
	}

}
