package com.thincode;

import com.thincode.beans.Usuario;

public class Empleado2 extends Usuario {

	public void prueba() {

		Empleado2 e = new Empleado2();
	
		// e.    protected publico
		
	
	}
	
	
}
