# Instrucciones
1. Descomprimir el archivo 
2. Adjuntar a los proyectos de eclipse

## Requerimientos
1. Correr el script en la bd
2. Cambiar los accesos