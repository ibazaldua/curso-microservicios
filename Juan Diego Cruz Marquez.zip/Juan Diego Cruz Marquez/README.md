# Ejercicios Realizados
En este repositorio se encuentran los ejercicios realizados por Juan Diego Cruz Marquez

## Contacto
correo: juan.cruz@thincode.com
telefono: 5524174649
