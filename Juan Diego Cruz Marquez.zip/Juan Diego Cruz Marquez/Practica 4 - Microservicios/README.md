# Instrucciones
1. Descomprimir todos los paquetes
2. Adjuntar todos los paquetes a eclipse

# Requisitos
Ninguno

# Ejecución
Levantar en el siguiente orden:
1. Config-Server
2. Eureka
3. Zuul
4. Todos los demas 
