package com.thincode.cuentaTarjCredito.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.thincode.cuentaTarjCredito.beans.Cuenta;

@Service
public class Servicio {
	
	
	public Cuenta getCuenta( int numcte ) {
		
		Cuenta cuenta = null;

		switch( numcte ) {
		case 1 :
			cuenta = new Cuenta( 12345678, "Cuenta de Credito / Oro", 1000 );
			break;
		case 2:
			cuenta = new Cuenta( 24680246, "Cuenta de Credito / Plata", 2000 );
			break;
		case 3:
			cuenta = new Cuenta( 36925814, "Cuenta de Credito / Platino", 3000 );
			break;
		default:
			break;
		}

		return cuenta;
	}
	

	public ArrayList<Cuenta> getCuentasCliente( int numcte ) {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();

		switch( numcte ) {
		case 1 :
			lista.add(new Cuenta( 12345678, "Tarjeta de Credito / Oro", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Credito / Plata", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Credito / Platino", 3000 ));
			break;
		case 2:
			lista.add(new Cuenta( 12345678, "Tarjeta de Credito / Credito Empresarial", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Credito / Credito Digital", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Credito / Factoraje", 3000 ));
			break;
		case 3:
			lista.add(new Cuenta( 12345678, "Tarjeta de Credito / Carta de Credito Comerciales", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Credito / Carta de Credito y Garantias", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Credito / Cadena Productiva Nafin", 3000 ));
			break;
		default:
			break;
		}

		return lista;
	}

	public Cuenta getCuenta() {
		Cuenta cta = new Cuenta( 12345678, "Tarjeta de Credito / Oro", 1000 );
		return cta;
	}

	public ArrayList<Cuenta> getCuentas() {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		lista.add( new Cuenta( 12345678, "Tarjeta de Credito / Oro", 1000 ));
		lista.add( new Cuenta( 24680246, "Tarjeta de Credito / Plata", 2000 ));
		lista.add( new Cuenta( 36925814, "Tarjeta de Credito / Platino", 3000 ));
		
		return lista;
	}

	
	
}
