package com.thincode.cuentaTarjCredito.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.cuentaTarjCredito.beans.Cuenta;
import com.thincode.cuentaTarjCredito.service.Servicio;

@RestController
public class Controlador {

	@Autowired
	Servicio serv;
	
	@GetMapping("/cuenta")
	public ResponseEntity<Cuenta>getCuenta() {
		Cuenta cta = serv.getCuenta();
		return new ResponseEntity<Cuenta>( cta, HttpStatus.OK );
	}
	
	@GetMapping("/cuenta/{cte}")
	public ResponseEntity<Cuenta>getCuenta( @PathVariable("cte")  int numcte ) {
		Cuenta cta = serv.getCuenta( numcte );
		return new ResponseEntity<Cuenta>( cta, HttpStatus.OK );
	}
	
	@GetMapping("/cuentas")
	public ResponseEntity<ArrayList<Cuenta>>getCuentas() {
		ArrayList<Cuenta> lista = serv.getCuentas();
		return new ResponseEntity<ArrayList<Cuenta>>( lista, HttpStatus.OK );
	}
	
	@GetMapping("/cuentas/{cte}")
	public ResponseEntity<ArrayList<Cuenta>>getCuentas( @PathVariable("cte")  int numcte ) {
		ArrayList<Cuenta> lista = serv.getCuentasCliente(numcte);
		return new ResponseEntity<ArrayList<Cuenta>>( lista, HttpStatus.OK );
	}
	
}
