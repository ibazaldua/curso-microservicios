package com.thincode.cuentaTarjDebito.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.thincode.cuentaTarjDebito.beans.Cuenta;

@Service
public class Servicio {
	
	public Cuenta getCuenta( int numcte ) {
		
		Cuenta cuenta = null;

		switch( numcte ) {
		case 1 :
			cuenta = new Cuenta( 12345678, "Cuenta de Debito / Perfiles", 1000 );
			break;
		case 2:
			cuenta = new Cuenta( 24680246, "Cuenta de Debito / Libreton", 2000 );
			break;
		case 3:
			cuenta = new Cuenta( 36925814, "Cuenta de Debito / Bnext", 3000 );
			break;
		default:
			break;
		}

		return cuenta;
	}
	

	public ArrayList<Cuenta> getCuentasCliente( int numcte ) {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();

		switch( numcte ) {
		case 1 :
			lista.add(new Cuenta( 12345678, "Tarjeta de Debito / Cuenta Básica General Banco Azteca", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Debito / Cuenta Básica Banregio", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Debito / Cuenta Básica Santander", 3000 ));
			break;
		case 2:
			lista.add(new Cuenta( 12345678, "Tarjeta de Debito / Cuenta Básica Santander", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Debito / Cuenta Básica General HSBC", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Debito / Cuenta Básica Banregio", 3000 ));
			break;
		case 3:
			lista.add(new Cuenta( 12345678, "Tarjeta de Debito / Cuenta Libretón Básico", 1000 ));
			lista.add(new Cuenta( 24680246, "Tarjeta de Debito / Bnext", 2000 ));
			lista.add(new Cuenta( 36925814, "Tarjeta de Debito / Cuenta Básica General Banco Azteca", 3000 ));
			break;
		default:
			break;
		}

		return lista;
	}
	
	public Cuenta getCuenta() {
		Cuenta cta = new Cuenta( 12345678, "Tarjeta de Debito / Perfiles", 1000 );
		return cta;
	}

	public ArrayList<Cuenta> getCuentas() {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		lista.add( new Cuenta( 12345678, "Tarjeta de Debito / Perfiles", 1000 ));
		lista.add( new Cuenta( 24680246, "Tarjeta de Debito / Libreton", 2000 ));
		
		return lista;
	}

	
	
	
	
	
	
	
	
	
}
