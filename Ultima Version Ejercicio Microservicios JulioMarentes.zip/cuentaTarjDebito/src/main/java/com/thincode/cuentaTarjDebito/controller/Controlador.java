package com.thincode.cuentaTarjDebito.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.thincode.cuentaTarjDebito.beans.Cuenta;
import com.thincode.cuentaTarjDebito.service.Servicio;


@RestController
public class Controlador {

	@Autowired
	Servicio serv;
	
	
	@GetMapping("/cuenta")
	public ResponseEntity<Cuenta> getCuenta() {
		Cuenta cta = new Cuenta( 12345678, "Tarjeta de Debito / Perfiles", 1000 );
		return new ResponseEntity<Cuenta>( cta, HttpStatus.OK );
	}
	
	@GetMapping("/cuenta/{cte}")
	public ResponseEntity<Cuenta> getCuenta( @PathVariable("cte")  int numcte ) {
		Cuenta cta = serv.getCuenta(numcte); 
		return new ResponseEntity<Cuenta>( cta, HttpStatus.OK );
	}
	
	@GetMapping("/cuentas")
	public ResponseEntity< ArrayList<Cuenta> > getCuentas() {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		lista.add(new Cuenta( 12345678, "Tarjeta de Debito / Perfiles", 1000 ));
		lista.add(new Cuenta( 24680246, "Tarjeta de Debito / Libreton", 2000 ));
		ResponseEntity<ArrayList<Cuenta>> respuesta = new ResponseEntity<ArrayList<Cuenta>>( lista, HttpStatus.OK ); 
		return respuesta;
	}

	@GetMapping("/cuentas/{cte}")
	public ResponseEntity< ArrayList<Cuenta> > getCuentasCliente ( @PathVariable("cte")  int numcte ) {
		ArrayList<Cuenta> lista = serv.getCuentasCliente(numcte); 
		ResponseEntity<ArrayList<Cuenta>> respuesta = new ResponseEntity<ArrayList<Cuenta>>( lista, HttpStatus.OK ); 
		return respuesta;
	}

	@GetMapping("/saludo")
	public String saludo() {
		return "Hola desde Cuentas";
	}
	
	
}
