package com.thincode.cuentaInversiones.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.thincode.cuentaInversiones.beans.Cuenta;

@Service
public class Servicio {

	public Cuenta getCuenta( int numcte ) {
		
		Cuenta cuenta = null;

		switch( numcte ) {
		case 1 :
			cuenta = new Cuenta( 12345678, "Cuenta de Inversion / Plazo Fijo", 1000 );
			break;
		case 2:
			cuenta = new Cuenta( 24680246, "Cuenta de Inversion / Cetes", 2000 );
			break;
		case 3:
			cuenta = new Cuenta( 36925814, "Cuenta de Inversion / Taza Variable", 3000 );
			break;
		default:
			break;
		}

		return cuenta;
	}
	

	public ArrayList<Cuenta> getCuentasCliente( int numcte ) {
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();

		switch( numcte ) {
		case 1 :
			lista.add(new Cuenta( 12345678, "Cuenta de Inversion / Plazo Fijo", 1000 ));
			lista.add(new Cuenta( 24680246, "Cuenta de Inversion / Cetes", 2000 ));
			lista.add(new Cuenta( 36925814, "Cuenta de Inversion / Taza Variable", 3000 ));
			break;
		case 2:
			lista.add(new Cuenta( 12345678, "Cuenta de Inversion / Compra-venta de divisas", 1000 ));
			lista.add(new Cuenta( 24680246, "Cuenta de Inversion / Derivados estructurados", 2000 ));
			lista.add(new Cuenta( 36925814, "Cuenta de Inversion / Valores gubernamentales", 3000 ));
			break;
		case 3:
			lista.add(new Cuenta( 12345678, "Cuenta de Inversion / Titulos bancarios", 1000 ));
			lista.add(new Cuenta( 24680246, "Cuenta de Inversion / Importaciones y exportaciones", 2000 ));
			lista.add(new Cuenta( 36925814, "Cuenta de Inversion / Arrendadora monex Variable", 3000 ));
			break;
		default:
			break;
		}

		return lista;
	}

}
