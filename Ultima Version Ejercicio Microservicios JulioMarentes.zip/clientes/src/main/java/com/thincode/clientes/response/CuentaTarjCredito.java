package com.thincode.clientes.response;

public class CuentaTarjCredito {

}
