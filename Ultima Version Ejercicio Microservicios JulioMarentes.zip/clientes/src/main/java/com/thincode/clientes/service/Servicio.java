package com.thincode.clientes.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.thincode.clientes.beans.Cliente;
import com.thincode.clientes.beans.Cuenta;

@Service
public class Servicio {
	
	private String urlCuenta[] = { "http://cuentaInversiones/cuenta", 
			"http://cuentaTarjCredito/cuenta",
			"http://cuentaTarjDebito/cuenta" };
	private String urlCuentas[] = { "http://cuentaInversiones/cuentas", 
			"http://cuentaTarjCredito/cuentas",
			"http://cuentaTarjDebito/cuentas" };

	private RestTemplate restTemplate;

	@Autowired
	public Servicio( RestTemplate restTemplate ) {
		this.restTemplate = restTemplate;
	}

	public Cliente getEstadoCuentaCliente( int numcte ) {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta>lista = new ArrayList<Cuenta>();
		Cuenta[] lista1 = null;
		String url;
		
		cte.setCliente(numcte);
		cte.setNombre( getNombreCliente( numcte ));
		cte.setCuenta(null);
		
		// cuentaInversion
		url = urlCuentas[0] + "/" + numcte;
		lista1 = getCuentaInversion( url, status);
		
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}

		// cuentaTarjCredito
		url = urlCuentas[1] + "/" + numcte;
		lista1 = getCuentaTarjCredito( url, status);
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}

		// cuentaTarjDebito
		url = urlCuentas[2] + "/" + numcte;
		lista1 = getCuentaTarjDebito( url, status);
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}
		
		cte.setCuenta( lista );
		
		return cte;
	}
	
	@HystrixCommand( fallbackMethod = "getCuentaInversion_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaInversion( String url, HttpStatus status ){
		Cuenta[] lista = null;
		
		try {
			ResponseEntity<Cuenta[]> response = restTemplate.getForEntity( url,  Cuenta[].class );
			if ( response.getStatusCode() == HttpStatus.OK ) {
				lista = response.getBody();
				status = HttpStatus.OK;
			} else {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} catch (Exception e) {
			return getCuentaInversion_fallback();
		}
		
		
		return lista;
	}
	
	public Cuenta[] getCuentaInversion_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de inversion no disponible", 0 )};
		return lista;
	}

	@HystrixCommand( fallbackMethod = "getCuentaTarjCredito_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaTarjCredito( String url, HttpStatus status ){
		Cuenta[] lista = null;
		

			try {
				ResponseEntity<Cuenta[]> response = restTemplate.getForEntity( url,  Cuenta[].class );
				if ( response.getStatusCode() == HttpStatus.OK ) {
					lista = response.getBody();
					status = HttpStatus.OK;
				} else {
					status = HttpStatus.INTERNAL_SERVER_ERROR;
				}
			} catch ( Exception e) {
				return getCuentaTarjCredito_fallback();
			}
		
		return lista;
	}
	
	public Cuenta[] getCuentaTarjCredito_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de Credito no disponible", 0 )};
		return lista;
	}

	@HystrixCommand( fallbackMethod = "getCuentaTarjDebito_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaTarjDebito(String url, HttpStatus status) {
		Cuenta[] lista = null;

		try {
			ResponseEntity<Cuenta[]> response = restTemplate.getForEntity(url, Cuenta[].class);
			if (response.getStatusCode() == HttpStatus.OK) {
				lista = response.getBody();
				status = HttpStatus.OK;
			} else {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} catch (Exception e) {
			return getCuentaTarjDebito_fallback();
		}

		return lista;
	}
	
	public Cuenta[] getCuentaTarjDebito_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de Debito no disponible", 0 )};
		return lista;
	}
	
	public String getNombreCliente( int numCliente ) {
		
		String nombre;

		switch( numCliente ) {
		case 1:
			nombre="Julio Cesar Marentes";
			break;
		case 2:
			nombre="Anna Romina Marentes";
			break;
		case 3:
			nombre="Bruno Sebastian Marentes";
			break;
		default:
			nombre="Cliente no localizado";
			break;
		}
		return nombre;
	}
	
	public void obtenEstadoCuentaCliente( int numcte ) {
		
		
	}
	
	
	

}
