package com.thincode.clientes.response;

public class CuentaTarjDebito {

}
