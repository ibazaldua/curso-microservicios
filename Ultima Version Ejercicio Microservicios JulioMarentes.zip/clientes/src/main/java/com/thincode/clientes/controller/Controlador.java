package com.thincode.clientes.controller;


import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.thincode.clientes.beans.Cliente;
import com.thincode.clientes.beans.Cuenta;
import com.thincode.clientes.service.Servicio;

@RestController
public class Controlador {
	
	@Value("${constants.version}")
	private String version;
	
	private String urlCuenta[] = { 	"http://cuentaInversiones/cuenta",
									"http://cuentaTarjCredito/cuenta",
									"http://cuentaTarjDebito/cuenta"
			};
	private String urlCuentas[] = { "http://cuentaInversiones/cuentas",
									"http://cuentaTarjCredito/cuentas",
									"http://cuentaTarjDebito/cuentas"
	};
	
	private RestTemplate restTemplate;
	
	@Autowired
	Servicio serv;
	
	@Autowired
	public Controlador( RestTemplate restTemplate ) {
		this.restTemplate = restTemplate;
	}
	
	@GetMapping("/cliente/{cte}")
	@HystrixCommand( fallbackMethod = "getCuenta_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public ResponseEntity<Cliente> getCliente( @PathVariable("cte") int numcte) {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		Cuenta cuenta = null;
		
		cte.setCliente(numcte);
		cte.setNombre( serv.getNombreCliente(numcte));
		cte.setCuenta(null);
		
		ResponseEntity<Cuenta> response = restTemplate.getForEntity( urlCuenta[0], Cuenta.class );
		if ( response.getStatusCode() == HttpStatus.OK ) {
			cuenta=response.getBody();
			lista.add(cuenta);
			cte.setCuenta( lista );
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Cliente>( cte, status );
	}

	
	public ResponseEntity<Cliente> getCuenta_fallback( int numcte ) {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta> lista = new ArrayList<Cuenta>();
		
		cte.setCliente(1);
		cte.setNombre( serv.getNombreCliente(numcte));
		lista.add( new Cuenta( 0, "Informacion de Cuentas no disponible", 0  ) );
		cte.setCuenta(lista);
		
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	@GetMapping("/estadoCuenta/{cte}")
	public ResponseEntity<Cliente> getEstadoCuentaCliente(  @PathVariable("cte") int numcte  ) {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		
		cte = serv.getEstadoCuentaCliente(numcte);
		
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	
	
	@GetMapping("/estadoCuenta")
	public ResponseEntity<Cliente> getEstadoCuenta() {
		HttpStatus status = HttpStatus.OK;
		Cliente cte = new Cliente();
		ArrayList<Cuenta>lista = new ArrayList<Cuenta>();
		Cuenta[] lista1 = null;
		
		cte.setCliente(1);
		cte.setNombre("Julio Marentes");
		cte.setCuenta(null);
		
		// cuentaInversion
		lista1 = getCuentaInversion(urlCuentas[0], status);
		
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}

		// cuentaTarjCredito
		lista1 = getCuentaTarjCredito(urlCuentas[1], status);
				
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}
		
		// cuentaTarjDebito
		lista1 = getCuentaTarjDebito(urlCuentas[2], status);
						
		for (int i = 0; i < lista1.length; i++) {
			lista.add(lista1[i]);
		}
		
		cte.setCuenta( lista );
		
		return new ResponseEntity<Cliente>( cte, status );
	}
	
	@HystrixCommand( fallbackMethod = "getCuentaInversion_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaInversion( String url, HttpStatus status ){
		Cuenta[] lista = null;
		
		try {
			ResponseEntity<Cuenta[]> response = restTemplate.getForEntity( url,  Cuenta[].class );
			if ( response.getStatusCode() == HttpStatus.OK ) {
				lista = response.getBody();
				status = HttpStatus.OK;
			} else {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} catch (Exception e) {
			return getCuentaInversion_fallback();
		}
		
		
		return lista;
	}
	
	public Cuenta[] getCuentaInversion_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de inversion no disponible", 0 )};
		return lista;
	}


	@HystrixCommand( fallbackMethod = "getCuentaTarjCredito_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaTarjCredito( String url, HttpStatus status ){
		Cuenta[] lista = null;
		

			try {
				ResponseEntity<Cuenta[]> response = restTemplate.getForEntity( url,  Cuenta[].class );
				if ( response.getStatusCode() == HttpStatus.OK ) {
					lista = response.getBody();
					status = HttpStatus.OK;
				} else {
					status = HttpStatus.INTERNAL_SERVER_ERROR;
				}
			} catch ( Exception e) {
				return getCuentaTarjCredito_fallback();
			}
		
		return lista;
	}
	
	public Cuenta[] getCuentaTarjCredito_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de Credito no disponible", 0 )};
		return lista;
	}

	@HystrixCommand( fallbackMethod = "getCuentaTarjDebito_fallback", commandProperties = {
			   @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", 
				value = "200")
	})
	public Cuenta[] getCuentaTarjDebito(String url, HttpStatus status) {
		Cuenta[] lista = null;

		try {
			ResponseEntity<Cuenta[]> response = restTemplate.getForEntity(url, Cuenta[].class);
			if (response.getStatusCode() == HttpStatus.OK) {
				lista = response.getBody();
				status = HttpStatus.OK;
			} else {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} catch (Exception e) {
			return getCuentaTarjDebito_fallback();
		}

		return lista;
	}
	
	public Cuenta[] getCuentaTarjDebito_fallback() {
		Cuenta[] lista = { new Cuenta( 0, "Informacion de Cuentas de Debito no disponible", 0 )};
		return lista;
	}

	
	@GetMapping("/version")
	public String version() {
		return "<h1>Version " + version + "</h1>";
	}
	
}
