package com.thincode.clientes.beans;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {

	private int cliente;
	private String nombre;
	private ArrayList<Cuenta> cuenta;
	
}
