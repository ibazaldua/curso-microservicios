package com.thincode.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.thincode.dao.IUsuarioDao;
import com.thincode.model.Usuario;
import org.mariadb.*;

public class UsuarioDaoImpl implements IUsuarioDao {

	public boolean guardarUsuario(Usuario u) {
		boolean guardado = false;
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			// Class.forName("com.mysql.jdbc.Driver");
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mariadb://localhost/db", "root", "");

			PreparedStatement stmt = conn.prepareStatement("INSERT INTO Usuario VALUES (?,?,?,?,?)");
			stmt.setString(1, u.getUsuario());
			stmt.setString(2, u.getNombre());
			stmt.setString(3, u.getCorreo());
			stmt.setString(4, u.getContrsena());
			stmt.setString(5, u.getFechaAlta());

			stmt.execute();
			guardado = true;
			conn.close();
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return guardado;
	}

	public List<Usuario> listarUsuarios()  {

		List<Usuario> listarUsuarios = new ArrayList<Usuario>();
		try {
			
			String sql = "SELECT * FROM Usuario";
			Class.forName("org.mariadb.jdbc.Driver");
			// Class.forName("com.mysql.jdbc.Driver");
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mariadb://localhost/db", "root", "");

			Statement statement = conn.createStatement();
			ResultSet resulSet = statement.executeQuery(sql);

			while (resulSet.next()) {
				Usuario u = new Usuario();
				u.setUsuario(resulSet.getString("usuario"));
				u.setNombre(resulSet.getString("nombre"));
				u.setCorreo(resulSet.getString("correo"));
				u.setContrsena(resulSet.getString("contrasena"));
				u.setFechaAlta(resulSet.getString("fechaAlta"));
				listarUsuarios.add(u);
			}
			
			conn.close();
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return listarUsuarios;
	}

}
