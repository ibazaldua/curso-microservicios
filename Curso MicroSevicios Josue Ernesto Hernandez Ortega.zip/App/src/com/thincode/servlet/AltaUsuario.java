package com.thincode.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.thincode.dao.IUsuarioDao;
import com.thincode.dao.impl.UsuarioDaoImpl;
import com.thincode.model.Usuario;
import com.thincode.util.UsuariosMasivos;

/**
 * Servlet implementation class AltaUsuario
 */
public class AltaUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AltaUsuario() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Usuario u = new Usuario();
		u.setUsuario(request.getParameter("txtUsuario"));
		u.setNombre(request.getParameter("txtNombre"));
		u.setCorreo(request.getParameter("txtCorreo"));
		u.setContrsena(request.getParameter("txtContrasena"));
		u.setFechaAlta(request.getParameter("txtFechaAlta"));
		
		int i = Integer.parseInt(request.getParameter("txtRegistros"));
		
		UsuariosMasivos uM = new UsuariosMasivos(i, u);
		
		 Thread hilo = new Thread(uM);
	       
		 hilo.start();
		
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/ConsultarUsuarios");
		 dispatcher.forward(request, response);
		
	}

}
