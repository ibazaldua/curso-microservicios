package com.thincode.main;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thincode.model.Registro;

public class ExpresionesDemo {
	private static Map<Integer, Registro> mapa = new HashMap<Integer, Registro>();
	private static List<Registro> lista  = new ArrayList<Registro>();

	public static void main(String[] args) {
		String opcion;
		int idBusqueda;
		do {
			System.out.println("-----MENU-------");
			System.out.println("1. Cargar archivo");
			System.out.println("2. Mostrar lista");
			System.out.println("3. Consulta especifica");
			System.out.println("4. Salir");

			Scanner lee = new Scanner(System.in);

			opcion = lee.nextLine();

			switch (opcion) {
			case "1":
				cargarArchivo();
				break;
			case "2":
				lista.forEach((registro) -> System.out.println(registro));
				break;
			case "3":
				System.out.println("Ingrese el ID a buscar: ");
				try {
				idBusqueda = lee.nextInt();
				try {
				System.out.println(mapa.get(idBusqueda).toString());
				}catch(NullPointerException ex) {
					System.out.println("Ese id no existe");
				}
				}catch(InputMismatchException e) {
					System.out.println("Debe ingresar un numero");
				}
				
				break;
			case "4":
				System.out.println("Saliendo...");
				break;
			default:
				System.out.println("Opcion incorrecta. Ingerese otra opci�n");
				break;
			}

		} while (!opcion.equalsIgnoreCase("4"));

	}
	
	public static void cargarArchivo() {
		lista = new ArrayList<Registro>();
		try {
            Scanner input = new Scanner(new File("resources/datos"));
            while (input.hasNextLine()) {
                String line = input.nextLine();
                separarExpresiones(line);
            }
            input.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
	}
	
	public static void separarExpresiones(String linea) {
		Pattern pattern = Pattern.compile(".*(\\d+)\\s+([\\w\\s]+)\\s+(\\d+)\\s+(\\d{2}/\\d{2}/\\d{4})\\s+([\\w.-]+@[\\w-]+\\.[a-z]+).*");
        Matcher matcher = pattern.matcher(linea);
        Registro registro;
       
        if (matcher.matches()) {
//            System.out.println("Group count: " + matcher.groupCount());
//            System.out.println("Group #1: " + matcher.group(1) +"]");
//            System.out.println("Group #2: " + matcher.group(2));
//            System.out.println("Group #3: " + matcher.group(3) +"]");
//            System.out.println("Group #4: " + matcher.group(4));
//            System.out.println("Group #5: " + matcher.group(5));
            
            registro = new Registro(Integer.parseInt(matcher.group(1)), matcher.group(2), Integer.parseInt(matcher.group(3)), matcher.group(4), matcher.group(5));
            mapa.put(Integer.parseInt(matcher.group(1)), registro);
            lista.add(registro);
        } else {
        	System.out.println("EL REGISTRO ".concat(linea).concat(" NO SE PUEDE GUARDAR"));
        }
	}

}
