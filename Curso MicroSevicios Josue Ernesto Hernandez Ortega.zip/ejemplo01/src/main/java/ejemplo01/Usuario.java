package ejemplo01;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString.Exclude;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Usuario {
	private String usuario;
	private String nombre;
	private Date fechaNacimiento;
	@Exclude
	private String password;
	private Integer edad;

}
