package com.thincode.edocta.bean;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CuentaList {
    private List<Cuenta> cuentas;
 
    public CuentaList() {
        cuentas = new ArrayList<>();
    }
 
    // standard constructor and getter/setter
}
