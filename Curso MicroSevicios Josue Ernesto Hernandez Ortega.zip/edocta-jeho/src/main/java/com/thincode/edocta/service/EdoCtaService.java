package com.thincode.edocta.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.thincode.edocta.bean.Cuenta;
import com.thincode.edocta.bean.CuentaList;
import com.thincode.edocta.bean.EstadoCuenta;
import com.thincode.edocta.hystrix.Resilencia;

@Service
public class EdoCtaService {

	public static Map<String, EstadoCuenta> mapa = new HashMap<String, EstadoCuenta>(){{
	      put("12345678", new EstadoCuenta("12345678","Josue Hernandez", null));
	      put("87654321", new EstadoCuenta("87654321","Pedro Moreno", null));
	      put("11111111", new EstadoCuenta("11111111","Ricardo Blanco", null));
	  }};
	  
	@Autowired  
	private RestTemplate restTemplate;
	
	@Autowired
	private Resilencia r;
	
	
	public ResponseEntity<EstadoCuenta> getEstadoCuenta (String numeroCliente) {
		HttpStatus status;
		EstadoCuenta estadoCuenta = new EstadoCuenta();
		estadoCuenta = mapa.get(numeroCliente);
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		
		if(estadoCuenta != null) {
			
			
			cuentas.addAll(r.getCuentasDebito(numeroCliente));
			
			cuentas.addAll(r.getCuentasCredito(numeroCliente));
			
			cuentas.addAll(r.getCuentasInversion(numeroCliente));
			
			
			if(cuentas != null)
				estadoCuenta.setCuentas(cuentas);
			
			status = HttpStatus.OK;
			
		}else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<EstadoCuenta>( estadoCuenta, status);
	}
	
//	@HystrixCommand(fallbackMethod = "getCuentasDebitoFallback")
//	public List<Cuenta> getCuentasDebito(String numeroCliente){
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		ResponseEntity<Cuenta[]> cuentasDebito = restTemplate.getForEntity("http://tdebito-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
//		
//		if(cuentasDebito.getStatusCode() == HttpStatus.OK) {
//			cuentas.addAll(Arrays.asList(cuentasDebito.getBody()));
//		}
//		
//		return cuentas;
//	}
//	
//	@HystrixCommand(fallbackMethod = "getCuentasCreditoFallback")
//	public List<Cuenta> getCuentasCredito(String numeroCliente){
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		ResponseEntity<Cuenta[]> cuentasCredito = restTemplate.getForEntity("http://tcredito-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
//		
//		if(cuentasCredito.getStatusCode() == HttpStatus.OK) {
//			cuentas.addAll(Arrays.asList(cuentasCredito.getBody()));
//		}
//		
//		return cuentas;
//	}
//	
//	@HystrixCommand(fallbackMethod = "getCuentasInversionFallback")
//	public List<Cuenta> getCuentasInversion(String numeroCliente){
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		ResponseEntity<Cuenta[]> cuentasInversion = restTemplate.getForEntity("http://inversion-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
//		
//		if(cuentasInversion.getStatusCode() == HttpStatus.OK) {
//			cuentas.addAll(Arrays.asList(cuentasInversion.getBody()));
//		}
//		
//		return cuentas;
//	}
//	
//	
//	public List<Cuenta> getCuentasDebitoFallback(String numeroCliente, Throwable error) {
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		
//			cuentas.add(new Cuenta(numeroCliente, "Debito no disponible", "", 0));
//		
//		return cuentas;
//	}
//	
//	public List<Cuenta> getCuentasCreditoFallback(String numeroCliente, Throwable error) {
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		
//			cuentas.add(new Cuenta(numeroCliente, "Credito no disponible", "", 0));
//		
//		return cuentas;
//	}
//	
//	public List<Cuenta> getCuentasInversionFallback(String numeroCliente, Throwable error) {
//		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
//		
//			cuentas.add(new Cuenta(numeroCliente, "Inversion no disponible", "", 0));
//		
//		return cuentas;
//	}
	
	
}
