package daoImp;

import java.util.ArrayList;

import modelo.Persona;
import dao.PersonaDao;

public class PersonaMySql implements PersonaDao {
	public static ArrayList<Persona> listaPersonas = new ArrayList<Persona>();

	@Override
	public void guardar(Persona p) {
		listaPersonas.add(p);
	}

	@Override
	public void actualizar(int id, Persona p) {
		listaPersonas.set(id, p);
	}

	@Override
	public void eliminar(int id) {
		listaPersonas.remove(id);
		
	}

	@Override
	public void consultar() {
		for (Persona persona : listaPersonas) {
			System.out.println(persona.toString());
		}
		System.out.println("-------------MySQL");
	}
	
	public void consultar(int id) {
		System.out.println(listaPersonas.get(id).toString());
		System.out.println("-------------MySQL");
	}
	
	public void prueba() {}

}
