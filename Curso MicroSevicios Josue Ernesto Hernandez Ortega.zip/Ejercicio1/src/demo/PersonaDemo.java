package demo;

import java.util.Date;

import daoImp.*;
import modelo.Persona;

public class PersonaDemo {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		PersonaMySql pSQL = new PersonaMySql();
		Persona pMod = new Persona("Juan", 20, new Date(100, 9, 10));
		
		pSQL.guardar(pMod);
		
		pMod = new Persona("Pedro", 23, new Date(97, 9, 10));
		
		pSQL.guardar(pMod);
		
		pMod = new Persona("Luis", 24, new Date(96, 9, 10));
		
		pSQL.guardar(pMod);
		
		pSQL.consultar();
		
		pMod = new Persona("Pedro Mod", 23, new Date(97, 9, 10));
		
		pSQL.actualizar(1, pMod);
		
		pSQL.eliminar(0);
		
		pSQL.consultar();
		
		pSQL.consultar(1);
		
		
		PersonaOracle pOra = new PersonaOracle();
		
		pMod = new Persona("Josue", 20, new Date(100, 9, 10));
		
		pOra.guardar(pMod);
		
		pMod = new Persona("Pablo", 23, new Date(97, 9, 10));
		
		pOra.guardar(pMod);
		
		pMod = new Persona("Daniel", 24, new Date(96, 9, 10));
		
		pOra.guardar(pMod);
		
		pOra.consultar();
		
		pMod = new Persona("Pablo Mod", 23, new Date(97, 9, 10));
		
		pOra.actualizar(1, pMod);
		
		pOra.eliminar(0);
		
		pOra.consultar();
		
		pOra.consultar(1);

	}

}
