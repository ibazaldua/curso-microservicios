package com.thincode.inversionjeho.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.thincode.inversionjeho.bean.Cuenta;

@Service
public class CuentaSevice {
	
	public static List<Cuenta> lista = new ArrayList<Cuenta>(){{
	      add(new Cuenta("12345678","1234567812345678","Perfiles",100));
	      add(new Cuenta("12345678","1234567812345678","Plazo",100));
	      add(new Cuenta("87654321","8765432187654321","Perfiles",100));
	      add(new Cuenta("87654321","8765432187654321","Plazo",100));
	      add(new Cuenta("11111111","1111111111111111","Perfiles",100));
	  }};
	  
	  
     public List<Cuenta> getCuentas(String numeroCliente){
    	 List<Cuenta> cuentasResult = new ArrayList<Cuenta>();
    	 for (Cuenta cuenta : lista) {
			if(cuenta.getNumeroCliente().equals(numeroCliente))
				cuentasResult.add(cuenta);
    	 }
    	 
    	 return cuentasResult;
     }

}
