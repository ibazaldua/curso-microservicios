package com.thincode.tdebitojeho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TdebitoJehoApplicationTests {

	@Test
	void contextLoads() {
	}

}
