package com.thincode.ejemplo02.demorest01.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.thincode.ejemplo02.demorest01.beans.Usuario;

@Repository
public interface UsuarioRepositoryJpa extends CrudRepository<Usuario, String> {
    //Usuario findByUsuario(String usuario);
}
