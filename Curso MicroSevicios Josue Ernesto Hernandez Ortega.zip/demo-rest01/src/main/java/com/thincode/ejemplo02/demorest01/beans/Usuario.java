package com.thincode.ejemplo02.demorest01.beans;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "UsuarioRest")
public class Usuario {
	@Id
	private String usuario;
	private String nombre;
	private String correo;
	private String password;
	private Integer edad;

}
