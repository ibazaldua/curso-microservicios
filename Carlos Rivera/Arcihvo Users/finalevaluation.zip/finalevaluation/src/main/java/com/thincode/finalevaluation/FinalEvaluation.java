package com.thincode.finalevaluation;

import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.thincode.finalevaluation.io.ReadFile;
import com.thincode.finalevaluation.model.User;


public class FinalEvaluation {

  private boolean flag = true;

  private Map<Integer, User> userMap;

  private Scanner scanner;

  public FinalEvaluation() {
    scanner = new Scanner(System.in);
  }

  public static void main(String args[]) {
    String opc = "";
    FinalEvaluation finalE = new FinalEvaluation();
    finalE.scanner = new Scanner(System.in);
    do {
      finalE.displayMenu();
      String input = finalE.scanner.next();
      if (!finalE.isValidInput(input)) {
        System.out.println("Invalid Input");
      } else {
        finalE.evaluteOption(Integer.valueOf(input));
      }
    } while (finalE.flag);

  }

  private void displayMenu() {
    System.out.println("1 ----- Cargar Archivo");
    System.out.println("2 ----- Desplegar Registros");
    System.out.println("3 ----- Buscar Registro por Indice");
    System.out.println("4 ----- Salir");
    System.out.println("Opcion: ");
  }

  private boolean isValidInput(String input) {
    return input.matches("[\\d]+");
  }

  private void setFlag(boolean value) {
    this.flag = value;
  }

  private void evaluteOption(Integer option) {
    switch (option) {
      case 1:
        userMap = new ReadFile().loadUsers();
        break;
      case 2:
        displayMap();
        break;
      case 3:
        System.out.println("Introduce secuencial:");
        displayUser(getUser(getSequential()));
        break;
      case 4:
        this.setFlag(false);
        break;
      default:
        System.out.println("Opcion no v�lida");

    }
  }

  private void displayMap() {
    if (userMap != null) {
      userMap.values().forEach(System.out::println);
    }else {
      System.out.println("EMPTY MAP");
    }
  }

  private Integer getSequential() {
    String input = scanner.next();
    Integer sequential = -1;
    if (isValidInput(input)) {
      sequential = Integer.valueOf(input);
    }
    return sequential;
  }

  private User getUser(Integer sequential) {
    return  userMap != null ? userMap.get(sequential) : null;
  }

  private void displayUser(User user) {
    if (user != null) {
      System.out.println(user);
    } else {
      System.out.println("No existe secuencial");
    }
  }
}
