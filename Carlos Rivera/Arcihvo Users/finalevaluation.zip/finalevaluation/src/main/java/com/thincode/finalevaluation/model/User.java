package com.thincode.finalevaluation.model;

import lombok.Data;

@Data
public class User {

  private Integer consecutive;
  private String name;
  private Integer age;
  private String dateOfBirth;
  private String email;
}
