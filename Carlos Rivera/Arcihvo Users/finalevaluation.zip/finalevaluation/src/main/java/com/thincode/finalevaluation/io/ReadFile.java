package com.thincode.finalevaluation.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.thincode.finalevaluation.model.User;

public class ReadFile {

  private static final String URL_FILE = "C:\\Users\\riverac\\Documents\\Microservicios\\users.txt";
  
  private static final String PATTERN = "([\\d]+)[\\s+]([a-zA-Z ]+)[\\s+](\\d+)[\\s+](\\d\\d/\\d\\d/\\d\\d\\d\\d)[\\s+]([\\w\\W]+@[\\w]+\\.com)";
  
  public Map<Integer, User> loadUsers(){
    String line = "";
    Scanner sc = null;
    User user = null;
    Map<Integer, User> userMap = new HashMap<>();
    try {
       sc = new Scanner(new FileInputStream(URL_FILE), "UTF-8");
      while(sc.hasNextLine()) {
        line = sc.nextLine();
        if( (user = this.buildUser(line)) != null )
          userMap.put(user.getConsecutive(), user);
      }
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }finally{
      if(sc != null)
        sc.close();
    }
    return userMap;
  }
  
  
  private User buildUser(String line) {
    User user = null;
    Matcher matcher = this.getMatcher(line);
    if(matcher.find()) {
      user = new User();
      user.setConsecutive(Integer.valueOf(matcher.group(1)));
      user.setName(matcher.group(2));
      user.setAge(Integer.valueOf(matcher.group(3)));
      user.setDateOfBirth(matcher.group(4));
      user.setEmail(matcher.group(5));
    }
    return user;
  }
  
  
  private Matcher getMatcher(String line) {
    return  Pattern.compile(ReadFile.PATTERN).matcher(line);
    
  }
}
