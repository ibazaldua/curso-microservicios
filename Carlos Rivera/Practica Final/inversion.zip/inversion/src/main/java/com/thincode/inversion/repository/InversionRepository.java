package com.thincode.inversion.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.thincode.inversion.entity.InversionEntity;

public interface InversionRepository extends CrudRepository<InversionEntity, Long>{

  List<InversionEntity> findByFkCliente(Long fkCliente);
}
