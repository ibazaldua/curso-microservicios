package com.thincode.inversion.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.thincode.inversion.entity.vo.CuentaVO;
import com.thincode.inversion.repository.InversionRepository;

@Service
public class InversionService {

  private InversionRepository repository;
  
  public InversionService(InversionRepository repository) {
    this.repository = repository;
  }
  
  public List<CuentaVO> getInversion(Long fkCliente){
    List<CuentaVO> lista = new ArrayList<>();
    repository.findByFkCliente(fkCliente).forEach(inversion -> {
      CuentaVO cuenta = new CuentaVO();
      cuenta.setNoCuenta(inversion.getNoCuenta());
      cuenta.setSaldo(inversion.getSaldo());
      cuenta.setTipo(inversion.getTipo());
      lista.add(cuenta);
    });
    return lista;
  }
}
