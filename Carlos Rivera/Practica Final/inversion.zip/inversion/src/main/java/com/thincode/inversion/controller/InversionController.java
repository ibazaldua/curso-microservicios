package com.thincode.inversion.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.inversion.entity.vo.CuentaVO;
import com.thincode.inversion.service.InversionService;

@RestController
@CrossOrigin
public class InversionController {
  
  private InversionService service;

  @Autowired
  public InversionController(InversionService service) {
    this.service = service;
  }
  
  @GetMapping("/inversion/{no_cliente}")
  public ResponseEntity<List<CuentaVO>> getInversion(@PathVariable("no_cliente") Long cliente){
    return new ResponseEntity<>(service.getInversion(cliente), HttpStatus.OK);
  }
}
