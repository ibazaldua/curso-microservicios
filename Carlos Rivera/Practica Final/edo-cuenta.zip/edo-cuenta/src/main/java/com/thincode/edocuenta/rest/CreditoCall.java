package com.thincode.edocuenta.rest;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.thincode.edocuenta.entity.vo.CuentaVO;
import com.thincode.edocuenta.util.Utileria;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CreditoCall {

  private RestTemplate restClient;
  
  private Utileria utileria;
  
  
  public CreditoCall(RestTemplate restClient, Utileria utileria) {
    this.restClient = restClient;
    this.utileria = utileria;
  }
  
  @HystrixCommand( fallbackMethod="fallbackMethod")
  public List<CuentaVO> getCredito(Long noCuenta){
    ResponseEntity<CuentaVO[]> response = restClient.getForEntity("http://credito-service/credito/" + noCuenta, CuentaVO[].class);
    return utileria.transform(response.getBody()); 
  }
  
  
  public List<CuentaVO> fallbackMethod(Long noCuenta, Throwable e){
    log.info("Error en invocacion de servicio de Credito");
    return new ArrayList<>();
  }
  
}
