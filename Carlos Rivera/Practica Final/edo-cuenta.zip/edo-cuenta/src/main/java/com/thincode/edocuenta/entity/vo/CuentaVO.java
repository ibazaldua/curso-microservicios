package com.thincode.edocuenta.entity.vo;

import lombok.Data;

@Data
public class CuentaVO {

  private String noCuenta;
  
  private String tipo;
  
  private Float saldo;
}
