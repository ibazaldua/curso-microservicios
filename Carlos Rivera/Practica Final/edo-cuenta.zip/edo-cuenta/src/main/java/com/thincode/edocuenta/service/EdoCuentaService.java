package com.thincode.edocuenta.service;

import java.util.ArrayList;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.thincode.edocuenta.entity.CuentaEntity;
import com.thincode.edocuenta.entity.vo.CuentaVO;
import com.thincode.edocuenta.entity.vo.EntityVO;
import com.thincode.edocuenta.repository.CuentaRepository;
import com.thincode.edocuenta.rest.CreditoCall;
import com.thincode.edocuenta.rest.DebitoCall;
import com.thincode.edocuenta.rest.InversionCall;

@Service
public class EdoCuentaService {

  private CuentaRepository repository;
  private DebitoCall debitoClient;
  private CreditoCall creditoClient;
  private InversionCall inversionClient;
  
  @Autowired
  public EdoCuentaService(CuentaRepository repository, CreditoCall creditoClient, DebitoCall debitoClient, InversionCall inversionClient) {
    this.repository = repository;
    this.debitoClient = debitoClient;
    this.creditoClient = creditoClient;
    this.inversionClient = inversionClient;
  }
  
  public EntityVO getCliente(Long noCuenta) {
    Optional<CuentaEntity> optional = repository.findByNoCuenta(noCuenta);
    EntityVO entity = null;
    if(optional.isPresent()) {
      entity = getEntityVo(optional.get());
      entity.getListaCuentas().addAll(debitoClient.getDebito(noCuenta));
      entity.getListaCuentas().addAll(creditoClient.getCredito(noCuenta));
      entity.getListaCuentas().addAll(inversionClient.getInversion(noCuenta));
    }
    return entity;
  }
  
  
  private EntityVO getEntityVo(CuentaEntity cuenta) {
    EntityVO entity = new EntityVO();
    entity.setNoCuenta(cuenta.getNoCuenta());
    entity.setNombre(cuenta.getNombre());
    entity.setListaCuentas(new ArrayList<CuentaVO>());
    return entity;
  }
  
  
}
