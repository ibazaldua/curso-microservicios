package com.thincode.edocuenta.entity.vo;

import java.util.List;
import lombok.Data;

@Data
public class ListCuentaVo {

  private List<CuentaVO> list;
}
