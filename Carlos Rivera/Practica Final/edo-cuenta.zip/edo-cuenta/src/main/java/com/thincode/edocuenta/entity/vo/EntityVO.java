package com.thincode.edocuenta.entity.vo;

import java.util.List;
import lombok.Data;

@Data
public class EntityVO {
  
  private String nombre;
  private Long noCuenta;
  List<CuentaVO> listaCuentas;

}
