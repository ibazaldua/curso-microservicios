package com.thincode.edocuenta.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.thincode.edocuenta.entity.CuentaEntity;

@Repository
public interface CuentaRepository extends CrudRepository<CuentaEntity, Long>{

  Optional<CuentaEntity> findByNoCuenta(Long noCuenta);
}
