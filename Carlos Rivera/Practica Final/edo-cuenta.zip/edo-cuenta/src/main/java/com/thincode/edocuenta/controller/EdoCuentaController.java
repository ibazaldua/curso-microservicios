package com.thincode.edocuenta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.edocuenta.entity.vo.EntityVO;
import com.thincode.edocuenta.service.EdoCuentaService;

@RestController
public class EdoCuentaController {
  
  private EdoCuentaService service;
  
  @Autowired
  public EdoCuentaController(EdoCuentaService service) {
    this.service = service;
  }
  
  @GetMapping("edoCuenta/{no_cliente}")
  public ResponseEntity<EntityVO> getCliente(@PathVariable("no_cliente") Long noCliente){
    EntityVO entity = service.getCliente(noCliente);
    return new ResponseEntity<>(entity, entity != null ? HttpStatus.OK : HttpStatus.NOT_FOUND);
  }

}
