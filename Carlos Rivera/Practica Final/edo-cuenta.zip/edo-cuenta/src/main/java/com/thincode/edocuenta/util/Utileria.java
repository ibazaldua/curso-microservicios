package com.thincode.edocuenta.util;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.thincode.edocuenta.entity.vo.CuentaVO;

@Component
public class Utileria {

  public List<CuentaVO> transform(CuentaVO[] array){
    List<CuentaVO> list = new ArrayList<>();
    for(CuentaVO cuenta : array) {
      list.add(cuenta);
    }
    return list;
  }
}
