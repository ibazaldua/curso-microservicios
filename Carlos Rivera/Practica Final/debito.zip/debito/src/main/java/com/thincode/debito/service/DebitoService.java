package com.thincode.debito.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.thincode.debito.entity.vo.CuentaVO;
import com.thincode.debito.repository.DebitoRepository;

@Service
public class DebitoService {

  private DebitoRepository repository;
  
  public DebitoService(DebitoRepository repository) {
    this.repository = repository;
  }
  
  public List<CuentaVO> getDebito(Long fkCliente){
    List<CuentaVO> lista = new ArrayList<>();
    repository.findByFkCliente(fkCliente).forEach(debito -> {
      CuentaVO cuenta = new CuentaVO();
      cuenta.setNoCuenta(debito.getNoCuenta());
      cuenta.setSaldo(debito.getSaldo());
      cuenta.setTipo(debito.getTipo());
      lista.add(cuenta);
    });
    return lista;
  }
}
