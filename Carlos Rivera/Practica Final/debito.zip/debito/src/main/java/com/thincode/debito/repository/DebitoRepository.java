package com.thincode.debito.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import com.thincode.debito.entity.DebitoEntity;

@Service
public interface DebitoRepository extends CrudRepository<DebitoEntity, Long>{

  List<DebitoEntity> findByFkCliente(Long fkCliente);
}
