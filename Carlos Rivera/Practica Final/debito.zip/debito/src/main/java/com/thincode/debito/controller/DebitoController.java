package com.thincode.debito.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.debito.entity.vo.CuentaVO;
import com.thincode.debito.service.DebitoService;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class DebitoController {

  private DebitoService service;
  
  public DebitoController(DebitoService service) {
    this.service = service;
  }
  
  @GetMapping("/debito/{no_cliente}")
  public ResponseEntity<List<CuentaVO>> getDebito(@PathVariable("no_cliente") Long cliente){
    return new ResponseEntity<>(service.getDebito(cliente), HttpStatus.OK);
  }
}
