package com.thincode.credito.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.thincode.credito.entity.CreditoEntity;

@Repository
public interface CreditoRepository extends CrudRepository<CreditoEntity, Long> {
  
  List<CreditoEntity> findByFkCliente(Long fkCliente);

}
