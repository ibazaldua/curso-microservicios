package com.thincode.credito.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.thincode.credito.entity.vo.CuentaVO;
import com.thincode.credito.repository.CreditoRepository;

@Service
public class CreditoService {

  private CreditoRepository repository;
  
  @Autowired
  public CreditoService(CreditoRepository repository) {
    this.repository = repository;
  }
  
  public List<CuentaVO> getCredito(Long fkCliente){
    List<CuentaVO> list = new ArrayList<>();
    repository.findByFkCliente(fkCliente).forEach(credito -> {
      CuentaVO cuenta = new CuentaVO();
      cuenta.setNoCuenta(credito.getNoCuenta());
      cuenta.setSaldo(credito.getSaldo());
      cuenta.setTipo(credito.getTipo());
      list.add(cuenta);
    });
    return list;
  }
}
