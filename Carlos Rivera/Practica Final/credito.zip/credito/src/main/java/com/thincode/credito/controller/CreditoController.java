package com.thincode.credito.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.credito.entity.vo.CuentaVO;
import com.thincode.credito.service.CreditoService;

@RestController
@CrossOrigin
public class CreditoController {

  private CreditoService service;
  
  @Autowired
  public CreditoController(CreditoService service) {
    this.service = service;
  }
  
  
  @GetMapping("/credito/{no_cliente}")
  public ResponseEntity<List<CuentaVO>> getCredito(@PathVariable("no_cliente") Long cliente ){
    return new ResponseEntity<>(service.getCredito(cliente), HttpStatus.OK);
  }
}
