package com.thincode.practicethree.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.thincode.practicethree.entity.UsuarioEntity;
import com.thincode.practicethree.repository.UsuarioRepository;
import com.thincode.practicethree.vo.UsuarioVO;

@Service
public class UsuarioService {

  @Autowired
  private UsuarioRepository repository;
  
  public void save(UsuarioVO usuario) {
    UsuarioEntity entity = new UsuarioEntity();
    buildEntity(usuario, entity);
    repository.save(entity);
    
  }
  
  public void update(UsuarioVO usuario) {
    UsuarioEntity entity = null;
    Optional<UsuarioEntity> optional = repository.findById(usuario.getId());
    if(optional.isPresent()) {
     entity = optional.get();
     buildEntity(usuario, entity);
      repository.save(entity);
    }
  }
  
  public void delete(Long id) {
    repository.deleteById(id);
  }
  
  public UsuarioVO get(String usuario) {
    UsuarioVO usuarioVo = null; 
    Optional<UsuarioEntity> optional = repository.findByUsuario(usuario);
    if(optional.isPresent()) {
      usuarioVo = buildVO( optional.get());
    }
    return usuarioVo;
  }
  
  public List<UsuarioVO> get(){
    List<UsuarioVO> lista = new ArrayList<>();
    repository.findAll().forEach(entity -> {
      UsuarioVO usuario = buildVO(entity);
      lista.add(usuario);
    });
    return lista;
  }
  
  private UsuarioVO buildVO(UsuarioEntity entity) {
    UsuarioVO usuario = new UsuarioVO();
    usuario.setId(entity.getId());
    usuario.setUsuario(entity.getUsuario());
    usuario.setNombre(entity.getNombre());
    usuario.setPassword(entity.getPassword());
    usuario.setCorreo(entity.getCorreo());
    usuario.setEdad(entity.getEdad());
    return usuario;
  }
  
  private void buildEntity(UsuarioVO usuario, UsuarioEntity entity) {
    entity.setUsuario(usuario.getUsuario());
    entity.setNombre(usuario.getNombre());
    entity.setPassword(usuario.getPassword());
    entity.setCorreo(usuario.getCorreo());
    entity.setEdad(usuario.getEdad());
  }
}
