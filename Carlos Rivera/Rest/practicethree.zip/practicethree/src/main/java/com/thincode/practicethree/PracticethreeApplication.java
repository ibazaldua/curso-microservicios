package com.thincode.practicethree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticethreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticethreeApplication.class, args);
	}

}
