package com.thincode.practicethree.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import com.thincode.practicethree.entity.UsuarioEntity;

public interface UsuarioRepository extends CrudRepository<UsuarioEntity, Long>{

  Optional<UsuarioEntity> findByUsuario(String usuario);
}
