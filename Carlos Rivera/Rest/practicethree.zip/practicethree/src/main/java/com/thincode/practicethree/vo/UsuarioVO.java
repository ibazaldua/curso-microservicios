package com.thincode.practicethree.vo;

import lombok.Data;

@Data
public class UsuarioVO {
  
  private Long id;

  private String usuario;
  
  private String nombre;
  
  private String password;
  
  private String correo;
  
  private Integer edad;
}
