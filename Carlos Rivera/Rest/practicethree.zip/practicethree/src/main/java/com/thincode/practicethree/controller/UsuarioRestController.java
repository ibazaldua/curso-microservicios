package com.thincode.practicethree.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.practicethree.service.UsuarioService;
import com.thincode.practicethree.vo.UsuarioVO;

@RestController
public class UsuarioRestController {

  @Autowired
  private UsuarioService service;
  
  @PostMapping("/usuario")
  public ResponseEntity save(@RequestBody UsuarioVO usuario) {
    service.save(usuario);
    return new ResponseEntity<>(HttpStatus.OK);
  }
  
  @DeleteMapping("/usuario/{id}")
  public ResponseEntity delete(@PathVariable("id") Long id) {
    service.delete(id);
    return new ResponseEntity<>(HttpStatus.OK);
  }
  
  @PutMapping("/usuario")
  public ResponseEntity update(@RequestBody UsuarioVO usuario) {
    service.update(usuario);
    return new ResponseEntity<>(HttpStatus.OK);
  }
  
  @GetMapping("/usuario/{usuario}")
  public ResponseEntity<UsuarioVO> get(@PathVariable("usuario") String usuario) {
    return new ResponseEntity<>(service.get(usuario), HttpStatus.OK);
  }
  
  @GetMapping("/usuario")
  public ResponseEntity<List<UsuarioVO>> get(){
    return new ResponseEntity<>(service.get(), HttpStatus.OK);
  }
}
