package com.thincode.practicethree.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "usuarios")
@Data
public class UsuarioEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;
  
  @Column(name = "usuario")
  private String usuario;
  
  @Column(name = "nombre")
  private String nombre;
  
  @Column(name = "password")
  private String password;
  
  @Column(name = "correo")
  private String correo;
  
  @Column(name = "edad")
  private Integer edad;

}
