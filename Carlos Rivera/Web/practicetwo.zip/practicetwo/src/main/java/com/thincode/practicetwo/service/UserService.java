package com.thincode.practicetwo.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.thincode.practicetwo.controller.UserController;
import com.thincode.practicetwo.entity.UserEntity;
import com.thincode.practicetwo.repository.UserRepository;
import com.thincode.practicetwo.util.Utilities;
import com.thincode.practicetwo.vo.UserVO;
import com.thincode.practicetwo.vo.UserVOTimeStamp;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

  @Autowired
  private UserRepository repository;
  
  @Autowired
  private Utilities utilities;
  
  private UserEntity usuario;
  
  private Integer occurrences;
  
  @Async
  public void save(UserVO usuario) {
    occurrences = usuario.getOccurrencias();
    UserVO userVo = utilities.copyData(usuario);
    IntStream.range(0, occurrences).forEach(i -> {
      this.usuario = utilities.getEntity(userVo);
      this.usuario.setFechaConsecutivo(LocalDateTime.now()  + " " + i);
      repository.save(this.usuario);
    });
  }
  
  public List<UserVOTimeStamp> getUsers(){
    List<UserVOTimeStamp> userList = new ArrayList<>();
    repository.findAll().forEach(user -> {
      UserVOTimeStamp userVO = new UserVOTimeStamp();
      userVO.setNombre(user.getNombre());
      userVO.setApPaterno(user.getApPaterno());
      userVO.setApMaterno(user.getApMaterno());
      userVO.setTimeStamp(user.getFechaConsecutivo());
      userList.add(userVO);
    });
    return userList;
  }
  
}
