package com.thincode.practicetwo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="users")
@Data
public class UserEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long idUser;
  
  @Column(name = "nombre")
  private String nombre;
  
  @Column(name = "ap_paterno")
  private String apPaterno;
  
  @Column(name = "ap_materno")
  private String apMaterno;
  
  @Column(name = "fecha_consecutivo")
  private String fechaConsecutivo;
  
}
