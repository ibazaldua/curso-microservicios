package com.thincode.practicetwo.vo;

import lombok.Data;

@Data
public class UserVO {
  
  private String nombre;
  
  private String apPaterno;

  private String apMaterno;
  
  private Integer occurrencias;
  
}
