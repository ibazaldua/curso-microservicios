package com.thincode.practicetwo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.thincode.practicetwo.service.UserService;
import com.thincode.practicetwo.vo.UserVO;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class UserController {
  
  @Autowired
  private UserService service;
  
  @GetMapping("/alta")
  public String index(Model model) {
    model.addAttribute("user", new UserVO());
    return "alta";
  }
  
  @PostMapping("/alta")
  public String alta(@ModelAttribute("user")  UserVO usuario) {
//    log.info(usuario.toString());
    service.save(usuario);
    return "alta";
  }
  
  @GetMapping("/consulta")
  public String consulta(Model model) {
    model.addAttribute("users", service.getUsers());
    return "consulta";
  }
}
