package com.thincode.practicetwo.vo;

import lombok.Data;

@Data
public class UserVOTimeStamp extends UserVO{
  private String timeStamp;
}
