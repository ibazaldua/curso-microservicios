package com.thincode.practicetwo.util;

import java.time.LocalDateTime;
import org.springframework.stereotype.Component;
import com.thincode.practicetwo.entity.UserEntity;
import com.thincode.practicetwo.vo.UserVO;

@Component
public class Utilities {

  public UserEntity getEntity(UserVO usuario) {
    UserEntity entity = new UserEntity();
    entity.setNombre(usuario.getNombre());
    entity.setApPaterno(usuario.getApPaterno());
    entity.setApMaterno(usuario.getApMaterno());
//    clear(usuario);
    return entity;
  }
  
  public UserVO copyData(UserVO usuario) {
    UserVO userVo = new UserVO();
    userVo.setNombre(usuario.getNombre());
    userVo.setApPaterno(usuario.getApPaterno());
    userVo.setApMaterno(usuario.getApMaterno());
    clear(usuario);
    return userVo;
  }
  
  public void clear(UserVO usuario) {
    usuario.setNombre(null);
    usuario.setApMaterno(null);
    usuario.setApPaterno(null);
    usuario.setOccurrencias(null);
  }
}
