package com.thincode.zuulservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@SpringBootTest
@EnableZuulProxy
class ZuulServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
