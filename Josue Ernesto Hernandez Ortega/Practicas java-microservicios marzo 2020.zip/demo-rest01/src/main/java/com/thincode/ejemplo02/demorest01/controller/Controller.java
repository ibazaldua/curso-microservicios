package com.thincode.ejemplo02.demorest01.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.thincode.ejemplo02.demorest01.beans.Usuario;
import com.thincode.ejemplo02.demorest01.repository.UsuarioRepositoryJpa;

@RestController
public class Controller {

	@Autowired
	UsuarioRepositoryJpa uRJ;
	
	@GetMapping("/version")
	public String version() {
		return "Rest V1.0";
	}
	
	@GetMapping("/usuarios")
	public List<Usuario> usuario() {
		return (List<Usuario>) uRJ.findAll();
	}
	
	@GetMapping("/usuario")
	public Optional<Usuario> usuario(@RequestBody String usuario) {
		return uRJ.findById(usuario);
	}
	
	@PostMapping("/usuario")
	public Usuario usuarioPost(@RequestBody Usuario usuario) {	
		return uRJ.save(usuario);
	}
	
	@DeleteMapping("/usuario")
	public void usuarioDelete(@RequestBody String usuario) {
		uRJ.deleteById(usuario);
	}
}
