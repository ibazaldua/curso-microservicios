package com.thincode.ejemplo02.demorest01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRest01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
