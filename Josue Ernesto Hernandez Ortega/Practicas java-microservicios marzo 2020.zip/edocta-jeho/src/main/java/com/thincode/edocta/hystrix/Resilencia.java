package com.thincode.edocta.hystrix;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.thincode.edocta.bean.Cuenta;

@Component
public class Resilencia {
	@Autowired  
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "getCuentasDebitoFallback")
	public List<Cuenta> getCuentasDebito(String numeroCliente){
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		ResponseEntity<Cuenta[]> cuentasDebito = restTemplate.getForEntity("http://tdebito-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
		
		if(cuentasDebito.getStatusCode() == HttpStatus.OK) {
			cuentas.addAll(Arrays.asList(cuentasDebito.getBody()));
		}
		
		return cuentas;
	}
	
	@HystrixCommand(fallbackMethod = "getCuentasCreditoFallback")
	public List<Cuenta> getCuentasCredito(String numeroCliente){
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		ResponseEntity<Cuenta[]> cuentasCredito = restTemplate.getForEntity("http://tcredito-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
		
		if(cuentasCredito.getStatusCode() == HttpStatus.OK) {
			cuentas.addAll(Arrays.asList(cuentasCredito.getBody()));
		}
		
		return cuentas;
	}
	
	@HystrixCommand(fallbackMethod = "getCuentasInversionFallback")
	public List<Cuenta> getCuentasInversion(String numeroCliente){
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		ResponseEntity<Cuenta[]> cuentasInversion = restTemplate.getForEntity("http://inversion-jeho/cuentas/".concat(numeroCliente), Cuenta[].class);
		
		if(cuentasInversion.getStatusCode() == HttpStatus.OK) {
			cuentas.addAll(Arrays.asList(cuentasInversion.getBody()));
		}
		
		return cuentas;
	}
	
	
	public List<Cuenta> getCuentasDebitoFallback(String numeroCliente, Throwable error) {
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		
			cuentas.add(new Cuenta(numeroCliente, "Debito no disponible", "", 0));
		
		return cuentas;
	}
	
	public List<Cuenta> getCuentasCreditoFallback(String numeroCliente, Throwable error) {
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		
			cuentas.add(new Cuenta(numeroCliente, "Credito no disponible", "", 0));
		
		return cuentas;
	}
	
	public List<Cuenta> getCuentasInversionFallback(String numeroCliente, Throwable error) {
		List<Cuenta> cuentas =  new ArrayList<Cuenta>();
		
			cuentas.add(new Cuenta(numeroCliente, "Inversion no disponible", "", 0));
		
		return cuentas;
	}

}
