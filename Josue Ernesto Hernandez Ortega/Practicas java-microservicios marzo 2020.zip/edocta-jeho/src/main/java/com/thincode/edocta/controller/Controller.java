package com.thincode.edocta.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.thincode.edocta.bean.Cuenta;
import com.thincode.edocta.bean.CuentaList;
import com.thincode.edocta.bean.EstadoCuenta;
import com.thincode.edocta.service.EdoCtaService;

@RestController
public class Controller {
	

	@Autowired
	EdoCtaService estadoCuentaService;

//	@Value("${constants.version}")
//	private String version;
	
	@GetMapping("/version")
	public String getVersion() {
		return "1.0.0";
	}
	
	@GetMapping("/edocta/{numCte}")
	public ResponseEntity<EstadoCuenta> getEstadoCuenta(@PathVariable("numCte") String numCte) {
		return estadoCuentaService.getEstadoCuenta(numCte);
	}
}
