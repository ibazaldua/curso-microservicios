package com.thincode.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionMariaDb {
	
	public static Connection conectar() {
		try {
			Class.forName("org.mariadb.jdbc.Dirver");
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mariadb://localhost:3306/db", "root", "");
			if (conn != null) return conn;
			else return null;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}catch(ClassNotFoundException e)
		{
			e.printStackTrace();
			return null;
		}
	}

}
