package com.thincode.dao;

import java.util.List;

import com.thincode.model.Usuario;

public interface IUsuarioDao {

	public boolean guardarUsuario(Usuario u);

	public List<Usuario> listarUsuarios();
}
