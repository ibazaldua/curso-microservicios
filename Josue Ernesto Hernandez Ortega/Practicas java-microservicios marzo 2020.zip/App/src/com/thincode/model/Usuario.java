package com.thincode.model;

import java.util.Date;

public class Usuario {
	String usuario;
	String nombre;
	String correo;
	String contrsena;
	String fechaAlta;
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getContrsena() {
		return contrsena;
	}
	public void setContrsena(String contrsena) {
		this.contrsena = contrsena;
	}
	public String getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	
	@Override
	public String toString() {
		return "Usuario [usuario=" + usuario + ", nombre=" + nombre + ", correo=" + correo + ", contrsena=" + contrsena
				+ ", fechaAlta=" + fechaAlta + "]";
	}
	
	
	
	

}
