package com.thincode.util;

import com.thincode.dao.IUsuarioDao;
import com.thincode.dao.impl.UsuarioDaoImpl;
import com.thincode.model.Usuario;

public class UsuariosMasivos implements Runnable {
    private Usuario usuario;
	private int registros;
	
	
	
	public UsuariosMasivos() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UsuariosMasivos(int registros, Usuario usuario) {
		super();
		this.usuario = usuario;
		this.registros = registros;
	}
	
	@Override
	public void run() {
		String usuarioStr = usuario.getUsuario();
		for (int i = 0; i < registros; i++) {
			usuario.setUsuario(usuarioStr + i);
			IUsuarioDao uDao = new UsuarioDaoImpl();
			uDao.guardarUsuario(usuario);
		}
		
	}
	
	

}
