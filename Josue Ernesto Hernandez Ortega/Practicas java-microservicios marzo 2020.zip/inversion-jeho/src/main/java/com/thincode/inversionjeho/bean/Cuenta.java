package com.thincode.inversionjeho.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cuenta {
	private String numeroCliente;
	private String cuenta;
	private String tipo;
	private long saldo;

}
