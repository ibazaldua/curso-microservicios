package com.thincode.inversionjeho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class InversionJehoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InversionJehoApplication.class, args);
	}

}
