package ejemplo01;

public class Main {

	public static void main(String[] args) {
		Usuario u = new Usuario();
		System.out.println(u);
		

	}

}
