package daoImp;

import java.util.ArrayList;

import modelo.Persona;
import dao.PersonaDao;

public class PersonaOracle implements PersonaDao {
	public static ArrayList<Persona> listaPersonasOracle = new ArrayList<Persona>();

	@Override
	public void guardar(Persona p) {
		listaPersonasOracle.add(p);
	}

	@Override
	public void actualizar(int id, Persona p) {
		listaPersonasOracle.set(id, p);
	}

	@Override
	public void eliminar(int id) {
		listaPersonasOracle.remove(id);
		
	}

	@Override
	public void consultar() {
		for (Persona persona : listaPersonasOracle) {
			System.out.println(persona);
		}
		System.out.println("-------------Oracle");
	}
	
	public void consultar(int id) {
		System.out.println(listaPersonasOracle.get(id));
		System.out.println("-------------Oracle");
	}
	
	

}
