package dao;

import modelo.Persona;

public interface PersonaDao {
	
	public void guardar(Persona p);
	
	public void actualizar(int id, Persona p);
	
	public void eliminar(int id);
	
	public void consultar();
	
	public void consultar(int id);

}
